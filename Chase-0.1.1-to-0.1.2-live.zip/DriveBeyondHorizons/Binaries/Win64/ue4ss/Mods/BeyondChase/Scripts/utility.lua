return function(M)
 local H,valid=M.H,M.valid
 local U={buttons={},tab='Match',message=''};local lib,layout,slate
 local modelUI=dofile(M.root..'/Scripts/player_models/ui.lua')(M,M.root,valid)
 local C={}
 for name,hex in pairs({bg='111923',panel='192430',card='283746',line='354454',white='F7F8F7',text='E2E9EC',muted='AFBDCA',dim='8394A3',ink='1D170F',red='16466B',accent='EFAA62',gold='F6B976',ice='87CDF6',orange='F3AB67',blueTint='1C3547',amberTint='3B2C24',blueLine='427799',amberLine='986C48'})do
  local function ch(k)local n=tonumber(hex:sub(k,k+1),16)/255;return n<=.04045 and n/12.92 or ((n+.055)/1.055)^2.4 end
  C[name]={R=ch(1),G=ch(3),B=ch(5),A=1}
 end
 local function new(k,outer)return StaticConstructObject(StaticFindObject('/Script/UMG.'..k),outer)end
 local function place(o,x,y,w,h)
  local s=U.canvas:AddChildToCanvas(o);s:SetPosition({X=U.x+x*U.scale,Y=U.y+y*U.scale});s:SetSize({X=w*U.scale,Y=h*U.scale});return o
 end
 local function rect(x,y,w,h,c)
  local o=new('Image',U.tree);o:SetColorAndOpacity(C[c]);place(o,x,y,w,h);o:SetVisibility(3);return o
 end
 local function text(t,x,y,w,h,size,color)
  local o=new('TextBlock',U.tree);o:SetText(FText(t));local f=o.Font;f.Size=math.max(10,math.floor(size*U.scale));o:SetFont(f)
  o:SetColorAndOpacity({SpecifiedColor=C[color or 'text'],ColorUseRule=0});place(o,x,y,w,h);o:SetVisibility(3);return o
 end
 local function button(t,x,y,w,h,fn,c,description)
  rect(x,y,w,h,c or 'card');text(t,x+16,y+(h<=36 and 5 or 12),w-32,30,h<=36 and 14 or 18)
  if description then text(description,x+16,y+46,w-32,34,13,'muted')end
  U.buttons[#U.buttons+1]={x=x,y=y,w=w,h=h,fn=fn}
 end
 function U.close()
  U.hover=nil
  
  U.opened=false;U.capture=nil;if U.saveStats then U.saveStats()end
  if valid(U.child)then U.child:RemoveFromParent()end;U.child=nil
  if valid(U.widget)then U.widget:RemoveFromParent()end
  if U.blocked and valid(U.pc)then
   -- Balance exactly the ignore-input pushes made by this overlay.
   U.pc:SetIgnoreLookInput(false);U.pc:SetIgnoreMoveInput(false)
   if valid(U.pawn)then U.pawn:EnableInput(U.pc)end
   U.pc.bShowMouseCursor=U.cursorBefore or false
   lib:SetInputMode_GameOnly(U.pc,true)
  end
  U.blocked=false;U.widget=nil;U.tree=nil;U.canvas=nil;U.buttons={};U.fields={}
 end

 local function plate(x,y,w,h,fill,border,r)
  local o=new('Image',U.tree);local radius=(r or 12)*U.scale
  o:SetBrush({DrawAs=4,TintColor={SpecifiedColor=C[fill],ColorUseRule=0},OutlineSettings={Color={SpecifiedColor=C[border or fill],ColorUseRule=0},Width=(border and 1 or 0)*U.scale,CornerRadii={X=radius,Y=radius,Z=radius,W=radius},RoundingType=0}})
  place(o,x,y,w,h);o:SetVisibility(3);return o
 end
 local function label(value,x,y,w,h,size,ink,bold,center)
  local o=text(value,x,y,w,h,size,ink);local font=o.Font;font.TypefaceFontName=FName(bold and 'Bold' or 'Regular');o:SetFont(font);o:SetClipping(1);if center then o:SetJustification(1)end;return o
 end
 local function picture(file,x,y,w,h)
  U.images=U.images or {};local tex=U.images[file]
  if not valid(tex)then tex=StaticFindObject('/Script/Engine.Default__KismetRenderingLibrary'):ImportFileAsTexture2D(U.pc,M.root..'/assets/'..file);U.images[file]=tex end
  if not valid(tex)then return end
  local o=new('Image',U.tree);o:SetBrushFromTexture(tex,false);place(o,x,y,w,h);o:SetVisibility(3)
 end
 local function action(value,x,y,w,h,fn,fill,ink,edge)
  local bg=plate(x,y,w,h,fill or 'card',edge or 'line',8)
  label(value,x+4,y+h/2-13,w-8,32,16,ink or 'text',true,true)
  if fn then U.buttons[#U.buttons+1]={x=x,y=y,w=w,h=h,fn=fn,plate=bg}end
 end
 local function money(n)
  local v=tostring(n);while true do local t,count=v:gsub('^(-?%d+)(%d%d%d)','%1,%2');v=t;if count==0 then return '$'..v end end
 end
 local function teamCard(state,team,x)
  local me=state.me or {};local cop=team=='cop';local title=cop and 'Police' or 'Runners'
  local accent=cop and 'ice' or 'orange';local edge=cop and 'blueLine' or 'amberLine'
  local seats=state.seats and state.seats[team]or{};local count=state.count and state.count[team]or 0
  local selected=me.team==team;local score=state.score and state.score[team]or 0
  plate(x,222,633,373,'panel',selected and edge or 'line',14)
  picture(team..'-banner.jpg',x+8,230,617,190)
  rect(x+8,419,617,3,accent)
  label(title,x+27,247,292,62,36,'white',true)
  label(cop and 'First garage' or 'Two stops ahead',x+29,311,260,32,15,'white',false)
  if state.phase=='running' or state.phase=='ended'then
   plate(x+28,362,105,39,'bg',edge,6);label(score..'  KILLS',x+30,369,101,27,15,accent,true,true)
  end
  label('TEAM ROSTER',x+22,435,285,25,12,'muted',true)
  label(count..' / 2',x+533,431,78,28,15,accent,true,true)
  for i=1,2 do local y=467+(i-1)*35;local seat=seats[i]
   plate(x+23,y+7,9,9,seat and (seat.online and accent or 'muted') or 'line',nil,5)
   label(seat and seat.name or 'Open seat',x+45,y-1,460,31,16,seat and 'text' or 'dim',seat~=nil)
   if seat then
    local badge=not seat.online and 'REJOINING' or state.phase=='lobby' and (seat.ready and 'READY' or 'PICKED TEAM') or nil
    if seat.you then badge=badge and ('YOU / '..badge) or 'YOU'end
    if badge then label(badge,x+441,y+2,162,23,11,seat.ready and accent or 'muted',true,true)end
   end
  end
  local can=state.phase and state.phase~='ended' and (state.phase=='lobby' or not me.team)and count<2
  if selected then action('Your team',x+18,541,597,40,nil,cop and 'blueTint' or 'amberTint',accent,edge)
  elseif can then action('Join '..title,x+18,541,597,40,function()M.action('join',team)end,'card','text',edge)
  else action(not state.phase and 'Lobby closed' or count==2 and 'Team full' or 'Roster locked',x+18,541,597,40,nil,'bg','dim','line')end
 end
 function U.render()
  if not valid(U.canvas)then return end
  local s=M.snapshot or {};local me=s.me or {};local host=U.pc:HasAuthority()
  U.canvas:ClearChildren();U.buttons={};U.hover=nil
  local vp=layout:GetViewportSize(U.pc);local dpi=layout:GetViewportScale(U.pc)
  U.scale=math.min(vp.X/1440,vp.Y/840)/dpi;U.x=(vp.X/dpi-1440*U.scale)/2;U.y=(vp.Y/dpi-840*U.scale)/2
  plate(38,27,1364,786,'bg','line',20)
  label('COPS',75,54,88,38,23,'white',true);label('/',151,54,23,39,23,'orange',true);label('RUNNERS',178,54,164,39,23,'white',true)
  local function nav(name,tab,x,w)
   local on=U.tab==tab
   if on then plate(x,47,w,48,'card',nil,10)end
   label(name,x,58,w,32,16,on and 'white' or 'muted',on,true)
   U.buttons[#U.buttons+1]={x=x,y=47,w=w,h=48,fn=function()U.tab=tab;U.modelEdit=nil;U.message='';U.render()end}
  end
  nav('Match','Match',513,118);nav('Appearance','Models',641,163)
  action('Close   F6',1231,47,136,46,U.close,'panel','muted','line')
  rect(70,111,1300,1,'line')
  if U.tab=='Models'then
   if me.team then
    if U.modelChoice==nil or not M.playerModels.catalog[U.modelChoice+1]or M.playerModels.catalog[U.modelChoice+1].team~=me.team then U.modelChoice=me.skin;U.modelEdit=nil end
    label(me.team=='cop' and 'POLICE' or 'RUNNERS',74,162,192,38,16,me.team=='cop' and 'ice' or 'orange',true)
    label('Appearance',74,208,188,38,20,'text',true)
    modelUI.render(U,{rect=rect,text=text,button=button,place=place,new=new})
   else label('Choose a team to select an appearance.',78,186,1250,63,24,'text',true)end
  else
   local title=({running='Live pursuit',ended='Round results'})[s.phase]or 'Pursuit lobby'
   label(title,73,136,740,67,36,'white',true)
   label('Endless run   /   2 vs 2',76,193,600,26,15,'muted',false)
   if me.team then
    label('TEAM FUNDS',1096,142,253,26,12,'muted',true,true);label(money(me.credits),1096,164,253,48,25,'text',true,true)
   end
   teamCard(s,'cop',73);teamCard(s,'runner',734)
   plate(73,616,1294,100,'panel','line',12)
   label('KILL TARGET',94,632,195,24,12,'muted',true)
   label(tostring(s.target or 10),94,654,82,49,25,'white',true)
   if host and s.phase and s.phase~='ended'then
    action('−',162,652,44,39,function()M.action('limit',math.max(1,s.target-1))end,'card','text')
    action('+',213,652,44,39,function()M.action('limit',math.min(999,s.target+1))end,'card','text')
   end
   rect(305,636,1,58,'line')
   local status,desc='Connecting to the host','The host needs the same version of Beyond Chase.'
   if s.phase=='lobby' then
    status=('%d / %d players ready'):format(s.votes or 0,s.total or 0)
    if s.preparing then desc='Everyone is ready. Loading safe team starts…'
    elseif (s.total or 0)>4 then desc='There are four seats. Every connected player must have one.'
    elseif (s.total or 0)<2 then desc='Invite one more player. Police and Runners each need a player.'
    elseif s.count.cop==0 or s.count.runner==0 then desc='Choose opposing teams, then ready up to start.'
    else desc='The pursuit starts automatically when everyone is ready.'end
   elseif s.phase=='running'then status='Pursuit in progress';desc=me.state=='down' and ('Respawn in '..(me.remaining or 0)..' s. Team wipes wait for both timers.')or 'One point per confirmed opposing-player kill.'
   elseif s.phase=='ended'then status=s.winner and (s.winner=='cop' and 'Police win' or 'Runners win')or 'Session ended';desc='The final team scores are shown above.'end
   label(status,335,632,620,37,20,'white',true);label(desc,336,673,673,29,14,'muted')
   if s.phase=='lobby' or (s.phase=='running' and me.team and not me.ready) then
    action(me.ready and 'Cancel ready' or 'Ready up',1080,637,263,56,me.team and function()M.action('ready',not me.ready)end or nil,me.team and 'orange' or 'card',me.team and 'ink' or 'muted')
   elseif s.phase=='ended'and host then action('Close results',1080,637,263,56,function()M.action('close')end,'orange','ink','orange')
   else label(host and 'HOST' or 'GUEST',1120,652,188,31,15,'muted',true,true)end
   if s.phase=='lobby' and me.team then action('Leave team',997,747,165,40,function()M.action('leave')end,'bg','muted','line')end
   if s.phase=='running' and me.ready and me.team=='cop' then
    local k=M.patrol.nearest(U.pc,M.appearance.vehicles)
    if k then action((M.appearance.switches[k] and 'Deactivate' or 'Activate')..' siren   J',810,744,342,43,M.patrol.toggle,'blueTint','ice','blueLine')end
   end
   if s.phase and s.phase~='ended'and host then action('End session',1201,747,163,40,function()M.action('close')end,'bg','muted','line')end
  end
  label(M.message or '',76,751,1100,36,15,'gold',false)
 end

 function U.open()
  if U.opened then U.close();return end
  local pc=H.GetPlayerController();local p=H.GetPlayer()
  if not valid(pc) or not valid(p) or not (p.IsLoaded or p.IsInitialized)then return end
  if not M.snapshot then M.message=nil;M.action('open')end
  U.tab='Match';U.modelChoice=nil
  U.pc=H.GetPlayerController();U.pawn=U.pc:K2_GetPawn();U.cursorBefore=U.pc.bShowMouseCursor
  lib=StaticFindObject('/Script/UMG.Default__WidgetBlueprintLibrary');layout=StaticFindObject('/Script/UMG.Default__WidgetLayoutLibrary');slate=StaticFindObject('/Script/UMG.Default__SlateBlueprintLibrary')
  U.widget=lib:Create(U.pc,StaticFindObject('/Script/UMG.UserWidget'),U.pc)
  U.tree=U.widget.WidgetTree;if not valid(U.tree)then U.tree=new('WidgetTree',U.widget);U.widget.WidgetTree=U.tree end
  U.canvas=new('CanvasPanel',U.tree);U.tree.RootWidget=U.canvas;U.widget:AddToViewport(10000)
  U.render();U.blocked=true;U.pc:SetIgnoreLookInput(true);U.pc:SetIgnoreMoveInput(true)
  if valid(U.pawn)then U.pawn:DisableInput(U.pc)end
  U.pc.bShowMouseCursor=true;lib:SetInputMode_UIOnlyEx(U.pc,U.widget,0,true);U.opened=true
 end
 function U.click()
  if not U.opened or U.child then return end
  -- Native conversion returns AddToViewport widget units, including DPI/window
  -- transforms. Do not pass opaque FGeometry through UE4SS's Lua table copier.
  local pixel,q={},{};slate:AbsoluteToViewport(U.pc,layout:GetMousePositionOnPlatform(),pixel,q)
  local x,y=(q.X-U.x)/U.scale,(q.Y-U.y)/U.scale
  for _,b in ipairs(U.buttons)do if x>=b.x and x<=b.x+b.w and y>=b.y and y<=b.y+b.h then if b.xy then b.fn(x,y)else b.fn()end;return end end

 end

 RegisterKeyBind(Key.F6,function()ExecuteInGameThread(function()local ok,e=pcall(U.open);if not ok then U.close();M.logOnce(e)end end)end)
 RegisterKeyBind(Key.J,function()if M.live() and M.localTeam()=='cop' then ExecuteInGameThread(M.patrol.toggle)end end)
 RegisterKeyBind(Key.LEFT_MOUSE_BUTTON,function()if U.opened then ExecuteInGameThread(function()local ok,e=pcall(U.click);if not ok then M.note(e)end end)end end)
 RegisterKeyBind(Key.ESCAPE,function()if U.opened then ExecuteInGameThread(U.close)end end)
 function U.hoverTick()
  if not U.opened or not valid(U.canvas)then return end
  local pixel,q={},{};slate:AbsoluteToViewport(U.pc,layout:GetMousePositionOnPlatform(),pixel,q)
  local x,y=(q.X-U.x)/U.scale,(q.Y-U.y)/U.scale;local hit
  for _,b in ipairs(U.buttons)do if b.plate and x>=b.x and x<=b.x+b.w and y>=b.y and y<=b.y+b.h then hit=b;break end end
  if hit~=U.hover then
   if U.hover and valid(U.hover.plate)then U.hover.plate:SetRenderOpacity(1)end
   if hit then hit.plate:SetRenderOpacity(.72)end;U.hover=hit
  end
 end
 return U
end
