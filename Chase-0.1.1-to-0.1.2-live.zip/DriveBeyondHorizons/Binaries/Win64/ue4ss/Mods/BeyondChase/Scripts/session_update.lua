-- Services are loaded anew for each pursuit, including by a running 0.1.1
-- lobby. Keep the existing UE4SS state, player connections and registered hooks.
return function(M,T)
 local S={reported={}}
 local valid=M.valid
 local legacy=M.version=='0.1.1'
 local serial=M.snapshot.serial
 local wire=legacy or not M.snapshot.build
 local function load(name)return dofile(M.root..'/Scripts/'..name..'.lua')(M)end
 local function participant(pc)
  local peer=M.peers[pc:GetAddress()]
  return peer and M.round and M.round.roster[peer.id]
 end
 local function linkOldRound()
  if not M.roundAdapter then
   M.replicas=load('replicas');M.placement=load('placement');M.patrol=load('patrol')
   M.route.loaded=load('route').loaded
   local stations=load('equipment')
   for _,k in ipairs({'stations','location','startingPC','client','reset'})do M.equipment[k]=stations[k]end
   local a=M.appearance;local mark,scan=a.mark,a.scan
   a.mark=function(actor,tag)
    if tag and (tag:match('^patrol_') or tag:match('^p%d_')) or not tag then M.replicas.set(actor,tag)end
    return mark(actor,tag)
   end
   a.scan=function()
    scan()
    if not M.live()then return end
    local cars=FindAllOf('AVS_Template_Vehicle_C')or{}
    local resolved=M.patrol.resolve(M.livePatrol,cars,FindAllOf('PlayerBase_C')or{})
    for _,car in ipairs(cars)do if valid(car)then
     local key=car:GetAddress();local on=resolved[key]
     if on~=nil then a.vehicles[key]=car;a.switches[key]=on end
    end end
   end
   M.roundAdapter=true
  end
  if M.round then
   S.round=M.round;S.plans=M.round.plans
   M.round.plans=function(r,clock,connected)
    for _,plan in ipairs(S.plans(r,clock,connected))do M.placement.place(plan)end
    return {}
   end
  end
  M.placement.reply=function(seq)T.network.call({op='arrival',serial=serial,seq=seq})end
 end
 local checks={services=true,paint=true,station=true,laptop=true}
 function S.fromPlayer(pc,msg)
  local member=participant(pc)
  if not member or not member.ready or msg.serial~=serial or not M.live()then return end
  if msg.op=='arrival' then M.placement.ack(pc,member,msg.seq)
  elseif msg.op=='chaseCheck' and checks[msg.step]then
   if msg.step=='services' then member.needsWire=msg.legacy==true end
   member.clientChecks=member.clientChecks or {}
   if not member.clientChecks[msg.step]then
    member.clientChecks[msg.step]=true
    M.log('0.1.2 guest '..member.team..' confirmed '..msg.step)
   end
  end
 end
 function S.fromHost(msg)
  if wire and msg.serial==serial and not M.H.GetPlayerController():HasAuthority()then
   M.liveTransfer=msg.transfer;M.livePatrol=msg.patrol
  end
 end
 function S.start()
  if legacy then linkOldRound()elseif wire then M.placement.reply=function(seq)T.network.call({op='arrival',serial=serial,seq=seq})end end
  M.log('0.1.2 pursuit services active on '..(M.round and 'host' or 'guest')..' for round '..serial:sub(1,8))
 end
 local function report(step)
  if not S.reported[step] and T.network.connected then
   T.network.call({op='chaseCheck',step=step,legacy=legacy,serial=serial});S.reported[step]=true
   M.log('0.1.2 local guest confirmed '..step)
  end
 end
 function S.tick()
  local pc=M.H.GetPlayerController()
  if not valid(pc)or not valid(pc.PlayerControlled)then return end
  local clock=M.game:GetTimeSeconds(pc)
  if clock<(S.next or 0)then return end;S.next=clock+.4
  if legacy then M.replicas.scan(clock)end
  if pc:HasAuthority()then
    for _,peer in pairs(T.network.peers)do if valid(peer.pc)then
     local member=participant(peer.pc)
     if member and member.ready and (legacy or member.needsWire)then
      local t=member.transfer
      local packet={op='pursuitWorld',serial=serial,transfer=t and {seq=t.seq,at=t.at},patrol=M.patrol.describe(peer.pc)}
      local key=M.json.encode(packet)
      if key~=peer.lastWorld or clock>=(peer.worldRefresh or 0)then
       T.network.send(peer.pc,packet);peer.lastWorld=key;peer.worldRefresh=clock+2
      end
     end
    end end
  elseif legacy then
   M.placement.client(pc,pc.PlayerControlled,clock);M.equipment.client(pc,pc.PlayerControlled,clock)
  end
  if pc:HasAuthority()then return end
  report('services')
  if T.ui.kind=='station'and T.ui.opened then report('station')end
  if T.laptop.active and T.ui.kind==M.localTeam() and T.ui.apps and #T.ui.apps>0 then report('laptop')end
  if not S.reported.paint then for _,r in pairs(M.patrol.cars)do
   if valid(r.siren)and next(r.materials)then report('paint');break end
  end end
 end
 function S.stop()
  M.liveTransfer=nil;M.livePatrol=nil
  if wire then M.placement.reply=nil end
  if not legacy then return end
  if S.round then S.round.plans=S.plans end
  M.equipment.reset();M.replicas.reset();M.placement.pending=nil
 end
 return S
end
