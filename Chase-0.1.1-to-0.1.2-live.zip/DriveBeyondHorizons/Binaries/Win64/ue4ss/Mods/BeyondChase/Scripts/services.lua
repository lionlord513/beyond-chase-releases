-- Tuning runs in this mod's Lua state, with its own roots and protocols.
-- Lifecycle wrappers keep vendor callbacks dormant after teardown.
return function(M)
 local env=setmetatable({},{__index=_ENV});local T={root=M.root,version='1.2.10',mode=M,valid=M.valid,message='',queue={}}
 local active=true;local hooks={}
 local session=dofile(M.root..'/Scripts/session_update.lua')(M,T)
 local function guarded(fn)return function(...)if active and M.live() then return fn(...)end end end
 env.RegisterHook=function(path,a,b)
  local x,y
  if b then x,y=RegisterHook(path,guarded(a),guarded(b))else x,y=RegisterHook(path,guarded(a))end
  hooks[#hooks+1]={path,x,y};return x,y
 end
 env.NotifyOnNewObject=function(path,fn)return NotifyOnNewObject(path,guarded(fn))end
 env.ExecuteInGameThreadWithDelay=function(ms,fn)return ExecuteInGameThreadWithDelay(ms,guarded(fn))end
 env.dofile=function(path)return assert(loadfile(path,'t',env))()end
 local function load(name,...)return env.dofile(M.root..'/Scripts/'..name..'.lua')(...)end
 T.status=function(msg)T.message=tostring(msg):gsub('^.-:%d+: ',''):sub(1,165);if T.ui then T.ui.refreshStatus=true end end
 T.enqueue=function(fn)if active and #T.queue<64 then T.queue[#T.queue+1]=fn end end
 T.json=M.json;T.policy=env.dofile(M.root..'/Scripts/policy.lua');T.storage=load('storage',M.root,T.json,T.policy)
 T.handling=load('handling',T);T.draft=T.policy.stock();T.vehicle=load('vehicle',T)
 T.delivery=load('delivery',T);T.induction=load('induction',T);T.draw=load('draw',T);T.ui=load('ui',T)
 T.network=load('network',T);T.laptop=load('laptop',T)
 T.storage.world='round'..M.snapshot.serial;T.storage.ready=true
 env.RegisterHook('/Game/BP/EbaySystem/AC_EbaySystem.AC_EbaySystem_C:Open PC',function(ctx,ref)
  local p=T.vehicle.player();if M.valid(p) and M.valid(p.AC_EbaySystem) and ctx:get():GetAddress()==p.AC_EbaySystem:GetAddress()then M.openPC=ref:get()end
 end)
 T.session=session;session.start()
 local frame=0
 local function tickSystem(fn)
  local ok,why=pcall(fn)
  if not ok then M.logOnce(why)end
 end
 function T.tick()
  tickSystem(session.tick);T.vehicle.install();local queue=T.queue;T.queue={}
  for _,fn in ipairs(queue)do local ok,e=pcall(fn);if not ok then T.status(e)end end
  frame=frame+1
  if frame%2==0 then tickSystem(T.network.tick);tickSystem(T.laptop.tick);tickSystem(T.ui.tick);tickSystem(T.vehicle.tick)end
  T.induction.tick()
  if frame%20==0 and M.localTeam()=='runner'then local p=T.storage.pollImport();if p then T.presetName=T.storage.importPreset(p);T.draft=p.tune;T.dirty=true;T.ui.refresh=true end end
 end
 function T.stop()
  active=false;session.stop()
  for _,r in pairs(T.vehicle.records)do pcall(T.vehicle.restore,r)end
  if T.laptop.active then pcall(T.laptop.close)end
  for _,r in pairs(T.laptop.items)do if M.valid(r.actor)and r.actor:HasAuthority()then r.actor:K2_DestroyActor()end end
  for _,r in pairs(T.induction.nitrous.items)do if M.valid(r.actor)and r.actor:HasAuthority()then r.actor:K2_DestroyActor()end end
  for _,f in ipairs({T.ui.reset,T.induction.reset,T.laptop.reset,T.network.reset,T.vehicle.reset})do pcall(f)end
  for _,h in ipairs(hooks)do pcall(UnregisterHook,table.unpack(h))end
 end
 return T
end

