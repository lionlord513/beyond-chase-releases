return function(M)
 local W={known={},stays={},nextSurvey=0};local valid=M.valid
 local mathlib=StaticFindObject('/Script/Engine.Default__KismetMathLibrary')
 local sys=StaticFindObject('/Script/Engine.Default__KismetSystemLibrary')
 local clear={R=0,G=0,B=0,A=0}
 local function xy(a,b)return (a.X-b.X)^2+(a.Y-b.Y)^2 end
 local function vec(v)return {X=v.X,Y=v.Y,Z=v.Z}end
 function W.safe(p,q,slot)
  if not q then return end
  for i=0,11 do
   local angle=(i+(slot or 1)*3)*math.pi/6;local radius=130+math.floor(i/4)*125
   local x,y=q.X+radius*math.cos(angle),q.Y+radius*math.sin(angle);local hit={}
   if sys:LineTraceSingle(p,{X=x,Y=y,Z=q.Z+450},{X=x,Y=y,Z=q.Z-800},0,false,{p},0,hit,true,clear,clear,0)and hit.ImpactNormal.Z>.82 then
    local c=hit.Component:Get();local actor=valid(c)and c:GetOwner()
    if valid(actor)and not actor:IsA(StaticFindObject('/Script/Engine.Pawn'))then
     local at={X=x,Y=y,Z=hit.ImpactPoint.Z+100}
     if not sys:CapsuleTraceSingle(p,at,{X=x,Y=y,Z=at.Z+1},40,91,0,false,{p},0,{},true,clear,clear,0)then return at end
    end
   end
  end
 end
 local function roadEnds()
  local roads={}
  for _,r in ipairs(FindAllOf('PRRoad')or{})do if valid(r)and r.IsRoadInitialized and #r.SplineMeshComponents>0 then
   local c=r.SplineMeshComponents[1];if valid(c)then local tr=c:K2_GetComponentToWorld()
    roads[#roads+1]={i=r.RoadIndex,a=vec(mathlib:TransformLocation(tr,c:GetStartPosition())),b=vec(mathlib:TransformLocation(tr,c:GetEndPosition()))}
   end
  end end
  table.sort(roads,function(a,b)return a.i<b.i end);return roads
 end
 local function progress(q,roads)
  local best,at,dist=nil,nil,math.huge
  for _,r in ipairs(roads)do local dx,dy=r.b.X-r.a.X,r.b.Y-r.a.Y;local len=dx*dx+dy*dy
   if len>0 then local t=math.max(0,math.min(1,((q.X-r.a.X)*dx+(q.Y-r.a.Y)*dy)/len));local p={X=r.a.X+t*dx,Y=r.a.Y+t*dy,Z=r.a.Z+t*(r.b.Z-r.a.Z)};local d=xy(p,q)
    if d<dist then dist=d;best=r.i+t;at=p end
   end
  end
  if dist<32000^2 then return best,at end
 end
 function W.release()
  if valid(W.watch)then if valid(W.manager)then W.manager:RemoveTargetActor(W.watch)end;if valid(W.spawner)then W.spawner:RemoveWatcher(W.watch)end;W.watch:K2_DestroyActor()end;W.watch=nil
 end
 local function focus(p,q)
  if not valid(W.watch)then
   local tr={Translation=q,Rotation={X=0,Y=0,Z=0,W=1},Scale3D={X=1,Y=1,Z=1}}
   local a=M.game:BeginDeferredActorSpawnFromClass(p,StaticFindObject('/Script/Engine.TargetPoint'),tr,1,nil,0);if not valid(a)then return end
   M.game:FinishSpawningActor(a,tr,0);a:SetReplicates(false);a:SetActorEnableCollision(false);W.watch=a;W.manager:AddTargetActor(a);W.spawner:AddWatcher(a)
  else W.watch:K2_SetActorLocation(q,false,{},true)end
 end
 function W.loaded(p,q)
  local hit={}
  if not sys:LineTraceSingle(p,{X=q.X,Y=q.Y,Z=q.Z+45},{X=q.X,Y=q.Y,Z=q.Z-170},0,false,{p},0,hit,true,clear,clear,0)then return false end
  return hit.ImpactNormal.Z>.75 and math.abs(hit.ImpactPoint.Z+100-q.Z)<60
 end
 function W.survey(p,now,chase)
  if now<W.nextSurvey then return end;W.nextSurvey=now+1
  local gs=M.game:GetGameState(p);W.spawner=valid(gs)and gs.LSLevelSpawner
  if not valid(W.spawner)then return end
  if not valid(W.manager)then for _,r in ipairs(FindAllOf('RoadManager')or{})do if valid(r)and valid(r:GetWorld())and r:GetWorld():GetAddress()==p:GetWorld():GetAddress()then W.manager=r;break end end end
  if not valid(W.manager)then return end
  -- A chase may finish far enough down the road for the garage to unload.
  -- Re-stream both previously surveyed starts before offering the next round.
  if W.previous and not W.starts and chase.phase=='lobby'then
   local team=W.garageReady and 'runner' or 'cop'
   local point=W.previous[team];focus(p,point)
   if W.safe(p,point)then
    if team=='cop'then W.garageReady=true else W.starts=W.previous end
   end
   return
  end
  local roads=roadEnds();if #roads==0 then return end
  local garage
  W.spawner.LevelsRep:ForEach(function(_,raw)
   local l=raw:get();local q=vec(l.Transform.Translation);local path=l.WorldSoftObjectPtrPath:ToString():lower()
   if path:find('spawnhouse',1,true) or path:find('startgarage',1,true)then garage=q end
   if path:find('/maps/levels/',1,true) and not path:find('detour',1,true) and not path:find('/l_rock_',1,true)then
    local key=('%s %.0f %.0f'):format(path,q.X,q.Y);local order,at=progress(q,roads)
    if order and not W.known[key] then W.known[key]={key=key,path=path,pos=q,road=at,order=order} end
    if W.known[key]then W.known[key].initialized=l.HasBeenInitialized end
   end
  end)
  local sorted={};for _,s in pairs(W.known)do sorted[#sorted+1]=s end;table.sort(sorted,function(a,b)return a.order<b.order end)
  if W.starts or chase.phase~='lobby'then return end
  local start,second
  for i,s in ipairs(sorted)do if s.path:find('spawnhouse',1,true) or s.path:find('startgarage',1,true)then start=s;second=sorted[i+2];break end end
  if not start then if garage then focus(p,garage)end;return end
  if second then
   focus(p,second.road)
   local c=W.safe(p,start.road);local r=W.safe(p,second.road)
   if c and r then W.starts={cop=start.road,runner=second.road};W.terminals={cop=start.pos,runner=second.pos};return end
  else focus(p,roads[#roads].b)end
 end
 function W.checkpoint(id,player,p,sites,now)
  local at=p:K2_GetActorLocation();local nearest,distance
  for _,s in pairs(W.known)do local d=math.min(xy(at,s.pos),xy(at,s.road))
   if d<14500^2 and (not distance or d<distance)then nearest=s;distance=d end
  end
  if not nearest then W.stays[id]=nil;return end
  sites.passed=nearest.road
  local v=p:GetVelocity();local still=v.X*v.X+v.Y*v.Y<80^2
  local old=W.stays[id]
  if still and old and old.key==nearest.key and xy(at,old.at)<250^2 then if now-old.since>=2 then sites.stopped=nearest.road end
  else W.stays[id]={key=nearest.key,since=now,at=vec(at)}end
 end
 function W.reset()W.release();W.previous=W.starts or W.previous;W.garageReady=nil;W.known={};W.starts=nil;W.stays={};W.nextSurvey=0;W.manager=nil;W.spawner=nil end
 W.focus=focus
 return W
end

