# Cops vs. Runners

A hosted pursuit on the endless road in Drive Beyond Horizons. Two police seats face two runner seats. The first team to score 10 opposing-player kills wins. The host can change the target in F6.

## Install on every player's PC

1. Close the game. Install the Beyond-compatible UE4SS loader for Drive Beyond Horizons if it is not already installed.
2. In Steam, open **Drive Beyond Horizons → Manage → Browse local files**.
3. Extract **Cops-vs-Runners-0.1.2.zip** into that game folder, alongside the existing **DriveBeyondHorizons** and **Engine** folders.
4. Check that the default Steam install now contains this exact file.

~~~text
C:\Program Files (x86)\Steam\steamapps\common\Drive Beyond Horizons\DriveBeyondHorizons\Binaries\Win64\ue4ss\Mods\BeyondChase\Scripts\main.lua
~~~

On another Steam library drive, the path from the game folder is identical. Keep the empty **enabled.txt** in **BeyondChase**. The game and UE4SS are the only runtime requirements. If you use Beyond Mod Manager, use **Add ZIP** with the same archive. Keep the host and guests on the same version.

With standalone Beyond Apocalypse or Beyond Tuning installed, Chase adds a small session hook to their Lua entry points and backs up each original under **BeyondChase/state**. If F6 asks for a restart after installing or updating those mods, restart the game once before readying up.

## Host and join

1. Start or load an ordinary endless run and invite players as usual. Any save name works. Everyone needs Beyond Chase 0.1.2.
2. During the run, any player can press **F6**, choose **Police** or **Runners**, then select **Ready up**. You can close F6 and keep playing, cancel your vote or leave the team before the pursuit begins. Changing teams clears your vote.
3. Everyone currently connected counts, including anyone who has never opened F6. Two to four players can play, with at least one on each team and up to two per side. When everyone is ready the host loads the starting positions, closes the lobby overlay, and places police at the first garage and runners at least two roadside stops ahead.
4. Use **Appearance** to select your model. Police wear the SciFi Soldier. Runners start as the Alien and may choose their ordinary player model. The selected uniform and team equipment activate when the pursuit begins.

## During the pursuit

Open the **starting computer** and select **Collect Equipment**. Each team can claim its kit once for free. Police get one mountable CAD laptop and two M4A1s. Runners get one mountable Tuning laptop and two AK-47s. Pick the items up beside the computer. Open the lid and interact with the laptop, or mount it using the same controls as Beyond Tuning.

**Police CAD** and **Beyond Tuning** are laptop-only. Police CAD tracks runners within 2.5 km on its north-up radar. Its requisitions screen sells M4A1s ($400), Lee-Enfields ($750), 30-round ammo packs ($100), single-use RPGs ($1,000) and golden turbos ($750). On the runner laptop, use the original **Car Tuning** app for tuning and nitrous. Open the separate **Equipment** icon for AK-47s ($350), hunting rifles ($600) and ammo ($100).

Each team starts with **$1,000 shared between its two players**. Every confirmed opposing-player kill adds **$250** to the killer’s team. Team purchases debit this session balance. Ending the session discards it. Your ordinary game wallet is separate.

When a cop enters a car, its exterior turns black with white doors and hood accents. The game’s native police lightbar mounts across the roof. Press **J** in or beside your patrol car to switch its lights and siren together, or use **F6 → Match → Activate/Deactivate siren**. The lightbar stays attached while switched off and while the car is parked. A runner takeover or session end restores the original finish.

One confirmed opposing-player kill earns one point. Friendly fire, environmental deaths and distance earn zero. Respawns take 10 seconds on your first death, 20 on your second and 30 thereafter. You return near your living teammate. When both teammates are down, they return together after both timers expire. The host checks their last stopped POI, last passed POI and starting point for safe ground.

The host can end the session from **F6 → Match**. Closing F6 alone leaves the match running. Chase-specific controls and services turn off when the round ends.

## First-person combat

Open **Purchase equipment** in Police CAD or **Equipment** on the runner laptop. Both stores sell small ($100), medium ($200) and large ($300) backpacks, a rail flashlight ($75) and a 2× sight ($150). Purchases arrive beside the buyer and use the team wallet.

A confirmed hit shows a white hitmarker and plays a short click. A headshot flashes gold with a distinct sound. A credited kill plays a cash-register sound and shows **+$250 Kill** to the shooter.

Equip a rifle and use the normal first-person aim and fire controls. The bundled Apocalypse systems provide iron sights, 2× optics, weapon-specific shot audio, M4 burst fire and individual rifle handling. Use **L** with a supported loose attachment in reach to fit it to an equipped rifle. Use **L** to toggle a fitted flashlight. You can also fit or detach attachments from the backpack inventory.

Press **Tab** to inspect a worn or nearby native backpack. Right-click to quick-store a targeted item when the prompt appears, drag items between inventory slots, and press **B** with empty hands to take off a worn bag. The small, medium and large bags use their original Apocalypse capacities. **Middle mouse** drops an equipped rifle.

## Updates

Install the public package through Beyond Mod Manager using **Add ZIP**. Once installed, use the manager's normal update check for newer versions. A 0.1.1 installation still points to the old private feed until it receives this package. Keep **state** and **presets** when updating manually.

Players already connected on 0.1.1 can extract the 0.1.2 ZIP into their game directories while the game is running. After all players have extracted it, the host can end **only the pursuit** in F6. Stay in the multiplayer game, reopen F6, choose teams and ready up. Chase loads the new pursuit services for that round. The ordinary installation path on a future launch uses 0.1.2 directly.

Release downloads and the update manifest are in the [public release feed](https://github.com/lionlord513/beyond-chase-releases/releases). The development repository stays private. Third-party credits are included in the ZIP.
