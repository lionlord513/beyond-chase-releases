-- A replicated actor attachment carries a real network reference to its parent.
-- Socket names on locally created scene components need not exist on a guest.
return function(M)
 local R={owned={},seen={}}
 local valid=M.valid
 local class=StaticFindObject('/Script/Engine.TargetPoint')
 local function prefix()return 'CVR_'..M.snapshot.serial..'_' end

 function R.set(parent,label)
  if not valid(parent)or not parent:HasAuthority()then return end
  local key=parent:GetAddress()
  local record=R.owned[key]
  if not label then
   if record and valid(record.actor)then record.actor:K2_DestroyActor()end
   R.owned[key]=nil;return
  end
  if record and valid(record.actor)and record.label==label then return end
  local a=record and record.actor
  if not valid(a)then
   local tr=parent:GetTransform()
   a=M.game:BeginDeferredActorSpawnFromClass(parent,class,tr,1,parent,0)
   if not valid(a)then return end
   M.game:FinishSpawningActor(a,tr,0)
   a.bAlwaysRelevant=true;a:SetReplicates(true);a:SetReplicateMovement(true)
   a:SetActorEnableCollision(false);a:SetActorTickEnabled(false)
  end
  a:K2_AttachToComponent(parent.RootComponent,FName(prefix()..label),0,0,0,false)
  R.owned[key]={actor=a,parent=parent,label=label}
  a:FlushNetDormancy();a:ForceNetUpdate()
 end
 function R.scan(clock)
  if clock<(R.next or 0)then return end
  R.next=clock+.4
  local found={};local start=prefix()
  for _,a in ipairs(FindAllOf('TargetPoint')or{})do if valid(a)then
   local parent=a:GetAttachParentActor()
   if valid(parent)then
    local name=a:GetAttachParentSocketName():ToString()
    if name:sub(1,#start)==start then found[parent:GetAddress()]=name:sub(#start+1)end
   end
  end end
  R.seen=found
  for key,r in pairs(R.owned)do if not valid(r.parent)then
   if valid(r.actor)then r.actor:K2_DestroyActor()end;R.owned[key]=nil
  end end
 end
 function R.label(parent)
  if not valid(parent)then return end
  local key=parent:GetAddress();local r=R.owned[key]
  return r and r.label or R.seen[key]
 end
 function R.reset()
  for _,r in pairs(R.owned)do if valid(r.actor)then r.actor:K2_DestroyActor()end end
  R.owned={};R.seen={};R.next=nil
 end
 return R
end
