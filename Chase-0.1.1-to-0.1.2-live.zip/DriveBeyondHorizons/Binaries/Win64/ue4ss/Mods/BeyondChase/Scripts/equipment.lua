return function(M,gear,controller,send)
 local E={};local valid=M.valid
 local function dist(a,b)return (a.X-b.X)^2+(a.Y-b.Y)^2+(a.Z-b.Z)^2 end
 local function pos(a)local p=a:K2_GetActorLocation();return {X=p.X,Y=p.Y,Z=p.Z}end
 local function notice(pc,text)if pc:GetAddress()==M.H.GetPlayerController():GetAddress()then M.note(text)else send(pc,{op='notice',text=text})end end
 function E.stations(player)
  local starts=M.route.starts;if not starts then return end
  for _,team in ipairs({'cop','runner'})do
   if not valid(M.stations[team])then
    local anchor=starts[team];local poi=M.route.terminals and M.route.terminals[team] or anchor;local closest,best=nil,12000^2
    for _,a in ipairs(FindAllOf('BP_eBayPC_C')or{})do
     if valid(a) and valid(a:GetWorld()) and a:GetWorld():GetAddress()==player:GetWorld():GetAddress()then
      local at=pos(a);local d=dist(at,poi);if not M.replicas.label(a) and d<best then closest,best=a,d end
     end
    end
    if not closest then
     local at=M.route.safe(player,anchor,3)
     if at then
      at.Z=at.Z-96
      local tr={Translation=at,Rotation={X=0,Y=0,Z=0,W=1},Scale3D={X=1,Y=1,Z=1}}
      local cls=LoadAsset('/Game/BP/EbaySystem/BP_eBayPC.BP_eBayPC_C')
      closest=M.game:BeginDeferredActorSpawnFromClass(player,cls,tr,1,nil,0)
      if valid(closest)then
       M.game:FinishSpawningActor(closest,tr,0);closest.bAlwaysRelevant=true;closest:SetReplicates(true)
       closest:SetReplicateMovement(true);closest:FlushNetDormancy();closest:ForceNetUpdate()
       M.actors[#M.actors+1]=closest
      end
     end
    end
    if valid(closest)then M.stations[team]=closest;M.replicas.set(closest,'station_'..team)end
   end
  end
 end
 function E.location(team)local a=M.stations[team];if valid(a)then local q=M.placement.absolute(a,pos(a));return {X=math.floor(q.X),Y=math.floor(q.Y),Z=math.floor(q.Z)}end end
 function E.startingPC(a)
  local s=M.snapshot;if not s or s.phase~='running' or not s.me or not s.me.team then return false end
  local q=s.me.station
  if valid(a)then
   local label=M.replicas.label(a)
   if label then return label=='station_'..s.me.team end
   return q and dist(M.placement.absolute(a,pos(a)),q)<100^2
  end
  -- The guest HUD can open from a native client notification without the Open PC hook.
  local p=M.H.GetPlayer()
  return q and valid(p) and dist(M.placement.absolute(p,pos(p)),q)<550^2
 end
 function E.reset()
  if valid(E.mirror)then E.mirror:K2_DestroyActor()end
  E.mirror=nil;E.nextCheck=nil
 end
 function E.client(pc,p,clock)
  if clock<(E.nextCheck or 0)then return end
  E.nextCheck=clock+1
  local me=M.snapshot.me;local q=me.station
  if not q then return end
  local at=M.placement.localPoint(p,q)
  local close=dist(pos(p),at)<12000^2
  local using=valid(E.mirror) and valid(M.openPC) and E.mirror:GetAddress()==M.openPC:GetAddress() and
   valid(p.AC_EbaySystem) and valid(p.AC_EbaySystem.HUDREF) and p.AC_EbaySystem.HUDREF:IsInViewport()
  if not close or me.claimed then
   if valid(E.mirror)and not using then E.reset()end;return
  end
  for _,a in ipairs(FindAllOf('BP_eBayPC_C')or{})do
   if valid(a)and valid(a:GetWorld())and a:GetWorld():GetAddress()==p:GetWorld():GetAddress() and
    (not valid(E.mirror)or E.mirror:GetAddress()~=a:GetAddress()) and dist(pos(a),at)<100^2 then
    if valid(E.mirror)and not using then E.reset()end;return
   end
  end
  if valid(E.mirror)then return end
  -- Some POI desktops exist only in the host's streamed level. The guest
  -- gets the same native desktop at the host's station; collection remains an RPC.
  local tr={Translation=at,Rotation={X=0,Y=0,Z=0,W=1},Scale3D={X=1,Y=1,Z=1}}
  local cls=LoadAsset('/Game/BP/EbaySystem/BP_eBayPC.BP_eBayPC_C')
  local a=M.game:BeginDeferredActorSpawnFromClass(p,cls,tr,1,nil,0)
  if not valid(a)then return end
  a.FirstTimeOpen=true;a.QuestGenerated=true
  M.game:FinishSpawningActor(a,tr,0);a:SetReplicates(false);a:K2_SetActorLocation(at,false,{},true)
  if valid(a.ItemSaver)then a.ItemSaver.SaveOnDistance=false end
  E.mirror=a
 end
 function E.collect(pc,id)
  local r=M.round;local p=assert(r.roster[id],'Choose a team')
  assert(r.phase=='running' and p.state=='alive','Start the pursuit to collect equipment')
  local a=M.stations[p.team];local pawn=pc.PlayerControlled
  assert(valid(a) and valid(pawn) and dist(pos(pawn),pos(a))<550^2,'Use your team’s starting computer')
  if pc:GetAddress()==M.H.GetPlayerController():GetAddress()then assert(E.startingPC(M.openPC),'Open the starting computer')end
  r.kits=r.kits or {}
  if r.kits[p.team]then notice(pc,'Your team has already collected its equipment');return end
  local t=assert(M.tuning,'Equipment is loading');local made={}
  local ok,err=pcall(function()
   for i=1,2 do made[i]=gear(pc,p.team=='cop' and 'm4' or 'ak',t.delivery.spot(pc))end
   t.laptop.spawn(pc,t.delivery.spot(pc))
  end)
  if not ok then for _,gun in ipairs(made)do if valid(gun)then gun:K2_DestroyActor()end end;error(err)end
  r.kits[p.team]=true;M.log(p.team..' starting kit delivered');notice(pc,p.team=='cop' and 'CAD laptop and two M4A1s delivered' or 'Tuning laptop and two AK-47s delivered')
 end
 function E.radar(pc,e)
  local r=M.round;assert(r.phase=='running' and M.team(pc)=='cop' and M.atShop(pc),'Open Police CAD on your laptop')
  local time=M.game:GetTimeSeconds(pc);if time<(e.nextRadar or 0)then return end;e.nextRadar=time+1
  local origin=pos(pc.PlayerControlled);local points={}
  for id,member in pairs(r.roster)do
   local other=member.team=='runner' and member.state=='alive' and controller(id)
   if other and valid(other.PlayerControlled)then
    local q=pos(other.PlayerControlled);local x,y=q.X-origin.X,q.Y-origin.Y
    if x*x+y*y<=250000^2 then points[#points+1]={x=math.floor(x/1000+.5)*10,y=math.floor(y/1000+.5)*10}end
   end
  end
  if pc:GetAddress()==M.H.GetPlayerController():GetAddress()then M.radar=points else send(pc,{op='radar',points=points})end
 end
 return E
end
