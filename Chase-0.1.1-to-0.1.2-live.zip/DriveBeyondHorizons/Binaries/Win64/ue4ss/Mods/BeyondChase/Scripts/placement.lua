-- The host picks and moves to the landing point. The owning client reconciles
-- its predicted pawn there after its local world has collision, then acknowledges.
return function(M)
 local P={}
 local function vec(v)return {X=v.X,Y=v.Y,Z=v.Z}end
 function P.absolute(p,q)return vec(M.game:RebaseLocalOriginOntoZero(p,q))end
 function P.localPoint(p,q)return vec(M.game:RebaseZeroOriginOntoLocal(p,q))end
 local function near(p,q,r)
  local v=p:K2_GetActorLocation()
  return (v.X-q.X)^2+(v.Y-q.Y)^2+(v.Z-q.Z)^2<=r*r
 end
 local function move(p,q)
  local cm=p.CharacterMovement
  if M.valid(cm)then cm:StopMovementImmediately()end
  return p:K2_TeleportTo(q,p:K2_GetActorRotation())
 end
 function P.host(pc,member,spot,localHost)
  local p=pc.PlayerControlled;local clock=M.game:GetTimeSeconds(p)
  local t=member.transfer
  if not t then
   member.transferSeq=(member.transferSeq or 0)+1
   t={seq=member.transferSeq,at=P.absolute(p,spot)};member.transfer=t
  end
  local at=P.localPoint(p,t.at)
  if localHost and M.valid(pc.Vehicle)then
   pc:InpActEvt_ExitCar_K2Node_EnhancedInputActionEvent_29({},0,0,nil);return false
  end
  if M.valid(pc.Vehicle)then return false end
  if t.moved and near(p,at,450) and (localHost or t.ack)then return true end
  if clock<(t.retry or 0)then return false end
  t.retry=clock+1
  -- DBH's owning-player RPC also corrects the client's predicted movement.
  -- Waiting for local terrain before sending this would leave distant POIs unloaded.
  if not localHost and (not t.hinted or not near(p,at,450))then
   p:ClientForceTeleport(at);t.hinted=true
  end
  if not t.moved or not near(p,at,450)then
   t.moved=move(p,at)
   if t.moved then p:ForceNetUpdate()end
  end
  return localHost and t.moved and near(p,at,450)
 end
 function P.ack(pc,member,seq)
  local t=member and member.transfer
  if t and t.seq==seq and M.valid(pc.PlayerControlled)then
   t.ack=near(pc.PlayerControlled,P.localPoint(pc.PlayerControlled,t.at),450)
  end
 end
 function P.client(pc,p,clock)
  local me=M.snapshot and M.snapshot.me;local t=M.liveTransfer or (me and me.transfer)
  if not t then P.pending=nil;return end
  if not P.pending or P.pending.seq~=t.seq then P.pending={seq=t.seq}end
  local localState=P.pending
  if clock<(localState.retry or 0)then return end
  localState.retry=clock+.45
  if M.valid(pc.Vehicle)then
   pc:InpActEvt_ExitCar_K2Node_EnhancedInputActionEvent_29({},0,0,nil);return
  end
  local at=P.localPoint(p,t.at)
  if not localState.started then
   localState.started=true;p:ClientForceTeleport(at)
  end
  if not M.route.loaded(p,at)then return end
  if not localState.placed or not near(p,at,450)then localState.placed=move(p,at)end
  if localState.placed and near(p,at,450)then
   if P.reply then P.reply(t.seq)else M.action('arrived',t.seq)end
  end
 end
 local valid=M.valid
 local function controller(id)
  local e=M.owners[id]
  if e and valid(e.pc)and valid(e.pc.PlayerState)then return e.pc end
 end
 local function alive(p)return valid(p)and valid(p.BP_PlayerStats)and not p.BP_PlayerStats.IsDead and p.BP_PlayerStats.Life>0 end
 local function now(pc)return M.game:GetTimeSeconds(pc)end
 function P.place(plan)
  local pcs,spots={},{}
  for i,id in ipairs(plan.ids)do pcs[i]=controller(id);if not pcs[i]or not valid(pcs[i].PlayerControlled)then return end end
  local anchors=plan.sites
  if plan.beside then local ally=controller(plan.beside);if not ally or not alive(ally.PlayerControlled)then return end;anchors={ally.PlayerControlled:K2_GetActorLocation()}end
  local allPending=true
  for i,id in ipairs(plan.ids)do
   local t=M.round.roster[id].transfer
   if t then spots[i]=M.placement.localPoint(pcs[i],t.at)else allPending=false end
  end
  if not allPending then
   for index,q in ipairs(anchors)do
    spots={};for i,pc in ipairs(pcs)do spots[i]=M.route.safe(pc.PlayerControlled,q,i)end
    if spots[1]and (#pcs==1 or spots[2]and (spots[2].X-spots[1].X)^2+(spots[2].Y-spots[1].Y)^2>85^2)then break end;spots={}
    if not plan.beside and #anchors>1 then
     local waiting=M.round.roster[plan.ids[1]]
     waiting.focused=waiting.focused or {}
     if not waiting.focused[index]then waiting.focused[index]=now(pcs[1]);M.route.focus(pcs[1].PlayerControlled,q)end
     if now(pcs[1])-waiting.focused[index]<4 then return end
    end
   end
  end
  if not spots[1]then if not plan.beside and anchors[1]then M.route.focus(pcs[1].PlayerControlled,anchors[1])end;return end
  local arrived=true
  for i,pc in ipairs(pcs)do
   local p=pc.PlayerControlled
   if not alive(p)then pc:ReviveWithBattery(p);p.BP_PlayerStats:AddLife(p.BP_PlayerStats.MaximumLife);p.BP_PlayerStats.IsDead=false;p.BP_PlayerStats:OnRep_IsDead();p:StopRagdollEvent(true)end
   local member=M.round.roster[plan.ids[i]]
   if not M.placement.host(pc,member,spots[i],pc:GetAddress()==M.H.GetPlayerController():GetAddress()) or not alive(p)then arrived=false end
  end
  if not arrived then return end
  for i,id in ipairs(plan.ids)do
   local player=M.round.roster[id];player.transfer=nil;M.log(player.team..' arrival confirmed');player.focused=nil;player.confirmedHit=nil;player.health=pcs[i].PlayerControlled.BP_PlayerStats.Life;M.round:spawned(id)
  end
 end
 return P
end
