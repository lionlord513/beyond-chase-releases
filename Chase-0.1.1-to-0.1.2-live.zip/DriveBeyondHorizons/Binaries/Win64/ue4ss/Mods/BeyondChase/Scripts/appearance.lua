return function(M)
 local valid,H=M.valid,M.H
 local policy=dofile(M.root..'/Scripts/player_models/policy.lua')
 local rows=policy.catalog
 rows[1].team='runner';rows[2].team='cop';rows[3].team='runner'
 local C={catalog=rows,policy=policy,selected=1}
 M.playerModels=C
 local visuals=dofile(M.root..'/Scripts/player_models/visuals.lua')(M,M.root,H,valid,M.log)
 C.paintRGB=visuals.rgb
 function C.colors(id)local me=M.snapshot and M.snapshot.me;return me and me.palettes and me.palettes[tostring(id)] or C.policy.stock(id)end
 function C.setColors(id,colors) M.action('colors',{id=id,colors=colors}) end
 local cache=dofile(M.root..'/Scripts/weapons/mesh_cache.lua')(M,H,valid)
 local defs=dofile(M.root..'/Scripts/weapons/catalog.lua')
 C.weaponMeshes=cache;C.definitions=defs
 local loadImages=dofile(M.root..'/Scripts/weapons/pbr_images.lua')(M.root,valid)
 local scene=StaticFindObject('/Script/Engine.SceneComponent')
 local I={Translation={X=0,Y=0,Z=0},Rotation={X=0,Y=0,Z=0,W=1},Scale3D={X=1,Y=1,Z=1}}
 local marks,rifles,applied={},{},{}
 function C.mark(actor,tag)
  if not valid(actor) then return end
  local k=actor:GetAddress();local old=marks[k]
  if (tag and (tag:match('^patrol_') or tag:match('^p%d_'))) or (not tag and old and old.tag:match('^patrol_'))then M.replicas.set(actor,tag)end
  if old and old.tag==tag and valid(old.c) then return end
  if old and valid(old.c) and tag and tag:match('^patrol_') and old.tag:match('^patrol_')then
   old.c:K2_AttachToComponent(actor.RootComponent,FName('Chase_'..tag),0,0,0,false)
   old.tag=tag;actor:FlushNetDormancy();actor:ForceNetUpdate();return
  end
  if old and valid(old.c)then old.c:K2_DestroyComponent(actor)end;marks[k]=nil
  if not tag then actor:ForceNetUpdate();return end
  if defs[tag] and M.combat then M.combat.remember(actor,tag)end
  local c=actor:AddComponentByClass(scene,true,I,false)
  c:K2_AttachToComponent(actor.RootComponent,FName('Chase_'..tag),0,0,0,false)
  c:SetComponentTickEnabled(false);c:SetIsReplicated(true);marks[k]={tag=tag,c=c,actor=actor};actor:FlushNetDormancy();actor:ForceNetUpdate()
 end
 local function tag(a)
  local received=M.replicas.label(a);if received then return received end
  for _,e in ipairs(a:K2_GetComponentsByClass(scene))do
   local n=e:get().AttachSocketName:ToString():match('^Chase_(.+)$');if n then return n end
  end
 end
 function C.available()
  return M.localTeam()=='runner' and {rows[3],rows[1]} or {rows[2]}
 end
 function C.select(id)M.action('skin',id)end
 C.tag=tag
 local function rifle(a,id)
  local m4=defs[id]
  local k=a:GetAddress();if rifles[k]then return end
  local base=a.SkeletalMesh;if not valid(base)then return end
  local mat=StaticFindObject('/Script/Engine.Default__KismetMaterialLibrary'):CreateDynamicMaterialInstance(a,LoadAsset(m4.MaterialParent),FName('ChaseM4'),0)
  for param,tex in pairs(loadImages('assets/'..id..'-textures.gltf'))do mat:SetTextureParameterValue(FName(param),tex)end
  mat:SetScalarParameterValue(FName('AODarkness'),1);mat:SetScalarParameterValue(FName('DiffuseBrightness'),1.35);mat:SetScalarParameterValue(FName('RoughnessBrightness'),1)
  local parts={};rifles[k]={actor=a,parts=parts,visible=base.bVisible}
  for _,part in ipairs(m4.Parts)do
   local tr=m4.Transform();local socket=part=='magazine' and m4.MagazineSocket or m4.BodySocket
   if part=='magazine' then tr=StaticFindObject('/Script/Engine.Default__KismetMathLibrary'):MakeRelativeTransform(tr,base:GetSocketTransform(FName(socket),2))end
   local c=a:AddComponentByClass(cache.class,true,tr,false);parts[#parts+1]=c
   c:SetCollisionEnabled(0);c:SetComponentTickEnabled(false);c:K2_AttachToComponent(base,FName(socket),0,0,0,false);c:K2_SetRelativeTransform(tr,false,{},true);cache.fill(a,c,id,part,mat)
  end
  base:SetVisibility(false,false);a.IsAutomatic=false;a.CanBeAutomatic=false;a.FireRate=m4.FireRate
 end
 C.renderRifle=rifle
 function C.rifleParts(a)local r=rifles[a:GetAddress()];return r and r.parts end
 function C.scan()
  local wanted={}
  local players=FindAllOf('PlayerBase_C')or{}
  for _,p in ipairs(players)do if valid(p)and p:GetFullName():find(':PersistentLevel.',1,true) then
   local raw=tag(p) or '';local id,pal=raw:match('^p(%d)_(.+)$');id=tonumber(id);if id and rows[id+1] and C.policy.validColors(id,pal) and (id~=0 or pal~=C.policy.stock(0)) then
    local ok,r=pcall(visuals.apply,p,nil,id,pal)
    if ok then wanted[p:GetFullName()]=r;visuals.syncWearables(r);visuals.syncRagdoll(r) else M.logOnce(r) end
   end
  end end
  for k,r in pairs(applied)do if not wanted[k]then visuals.remove(r)end end;applied=wanted
  local previous=C.switches or {};C.vehicles={};C.switches={};local changed=false
  local cars=FindAllOf('AVS_Template_Vehicle_C')or{}
  local remote=M.patrol.resolve(M.snapshot.patrol or M.livePatrol,cars,players)
  for _,a in ipairs(cars)do if valid(a)then
   local on=remote[a:GetAddress()]
   local state=tag(a);if on~=nil then state=on and 'patrol_on' or 'patrol_off'end
   if state=='patrol_on' or state=='patrol_off'then local k=a:GetAddress();C.vehicles[k]=a;C.switches[k]=state=='patrol_on';if previous[k]~=C.switches[k]then changed=true end end
  end end
  for _,a in ipairs(FindAllOf('AkWeapon_C')or{})do
   if valid(a) and a:GetFullName():find(':PersistentLevel.',1,true) and M.combat then M.combat.refreshWeapon(a)end
  end
  if M.ui and M.ui.opened and M.ui.tab=='Match' and (changed or next(previous) and not next(C.switches))then M.ui.render()end
 end
 function C.tick(now)
  if now>=(C.next or 0)then C.next=now+1;C.scan()end
  for _,r in pairs(applied)do if valid(r.actor)and (r.id==0 or valid(r.follower))then visuals.update(r,H.GetPlayer(),H.GetPlayerController())end end
  M.patrol.update(C.vehicles or {},now,C.switches)
 end
 function C.reset()
  for _,r in pairs(marks)do if valid(r.actor)and valid(r.c)then r.c:K2_DestroyComponent(r.actor);r.actor:ForceNetUpdate()end end
  for _,r in pairs(rifles)do if valid(r.actor)then r.actor.SkeletalMesh:SetVisibility(r.visible,false);for _,c in ipairs(r.parts)do if valid(c)then cache.remove(c);c:K2_DestroyComponent(r.actor)end end end end
  visuals.reset();cache.reset();M.patrol.reset();marks={};applied={};rifles={};C.vehicles={};C.next=0
 end
 return C
end

