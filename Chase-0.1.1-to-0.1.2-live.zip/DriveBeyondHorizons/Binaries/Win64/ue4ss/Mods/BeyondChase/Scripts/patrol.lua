-- Each peer fits the stock siren and exterior materials from the replicated
-- occupancy tag. The saved car color and the player's fitted parts stay owned by the game.
return function(M)
 local P={cars={}}
 local valid=M.valid
 local mathlib=StaticFindObject('/Script/Engine.Default__KismetMathLibrary')
 local paint=StaticFindObject('/Script/Engine.Default__KismetMaterialLibrary')
 local meshClass=StaticFindObject('/Script/Engine.MeshComponent')
 local dynamic=StaticFindObject('/Script/Engine.MaterialInstanceDynamic')
 local colorName=FName('Color')
 local black={R=.012,G=.015,B=.020,A=1}
 local white={R=.86,G=.88,B=.90,A=1}
 local identity={Translation={X=0,Y=0,Z=0},Rotation={X=0,Y=0,Z=0,W=1},Scale3D={X=1,Y=1,Z=1}}
 local function same(a,b)return valid(a) and valid(b) and a:GetAddress()==b:GetAddress()end
 local function contains(s,words)for _,w in ipairs(words)do if s:find(w,1,true)then return true end end end
 local bodyWords={'body','chassis','shell','cabine','cab_','carrosserie'}
 local exterior={'door','hood','bonnet','boot','trunk','gashatch','fuellid','fuel_lid','fender','wing','roof','bumper','spoiler','tailgate','porte','capot','coffre','aile','bodykit','bodywork','sidepanel'}
 local excluded={'window','glass','vitre','wheel','tire','tyre','light','bulb','lamp','interior','radio','seat','gauge','dash','chrome','mirror_glass','license','screen','grille','wireframe','visualizer','overlay','collision','suspension','exhaust'}
 local function assetName(c)
  local asset=c:IsA(StaticFindObject('/Script/Engine.StaticMeshComponent'))and c.StaticMesh or nil
  return valid(asset)and asset:GetFName():ToString():lower() or c:GetFName():ToString():lower()
 end
 local function restore(v)
  if valid(v.component) and same(v.component:GetMaterial(v.slot),v.overlay)then v.component:SetMaterial(v.slot,v.original)end
 end
 local function exteriorColor(actor,c,car)
  local asset=assetName(c)
  if contains(asset,excluded)then return end
  if same(actor,car)then
   if contains(asset,bodyWords)or contains(asset,exterior)then return contains(asset,{'door','porte','hood','capot','bonnet'}) and white or black end
   -- Some cars expose their body under a car-specific mesh name.
   if c:IsA(StaticFindObject('/Script/Engine.StaticMeshComponent')) and valid(c.StaticMesh) and valid(car.VehicleMesh)then
    local bounds=c.StaticMesh:GetBoundingBox()
    local length=math.max(bounds.Max.X-bounds.Min.X,bounds.Max.Y-bounds.Min.Y)
    if length>215 and bounds.Max.Z-bounds.Min.Z>55 then return black end
   end
  else
   local name=actor:GetFName():ToString():lower()
   if name:find('container',1,true)then return end
   if contains(asset,exterior) or (contains(name,exterior) and same(c,actor.RootMeshComponent))then
    return contains(name..asset,{'door','porte','hood','bonnet','capot'}) and white or black
   end
  end
 end
 local function paintActor(r,actor,seen)
  for _,slot in ipairs(actor:K2_GetComponentsByClass(meshClass))do
   local c=slot:get()
   if c:IsA(StaticFindObject('/Script/Engine.StaticMeshComponent')) or c:IsA(StaticFindObject('/Script/Engine.SkinnedMeshComponent'))then
    local tint=exteriorColor(actor,c,r.car)
    if tint then
     for i,name in ipairs(c:GetMaterialSlotNames())do
      local index=i-1;local k=c:GetAddress()..'/'..index;local mat=c:GetMaterial(index);local old=r.materials[k]
      if old and same(mat,old.overlay)then
       local live=mat:K2_GetVectorParameterValue(colorName)
       if math.abs(live.R-tint.R)+math.abs(live.G-tint.G)+math.abs(live.B-tint.B)>.006 then mat:SetVectorParameterValue(colorName,tint)end
       seen[k]=true
      elseif valid(mat) and mat:IsA(dynamic) and not contains(name:get():ToString():lower(),excluded)then
       local painted=false
       mat.VectorParameterValues:ForEach(function(_,v)if v:get().ParameterInfo.Name:ToString()=='Color'then painted=true end end)
       if painted and valid(mat.Parent)then
        local overlay=paint:CreateDynamicMaterialInstance(r.car,mat.Parent,FName('ChaseExterior'),0)
        overlay:CopyParameterOverrides(mat);overlay:SetVectorParameterValue(colorName,tint)
        c:SetMaterial(index,overlay);r.materials[k]={component=c,slot=index,original=mat,overlay=overlay};seen[k]=true
       end
      end
     end
    end
   end
  end
 end
 local function refreshPaint(r)
  local seen={};paintActor(r,r.car,seen)
  local attached={};r.car:GetAttachedActors(attached,true,true)
  for _,v in ipairs(attached)do local a=v:get();if valid(a) and not same(a,r.siren)then paintActor(r,a,seen)end end
  for k,v in pairs(r.materials)do if not seen[k]then restore(v);r.materials[k]=nil end end
 end
 local function roof(car)
  local body=car.VehicleMesh;if not valid(body)then return end
  local low,high={},{};body:GetLocalBounds(low,high)
  local width=high.Y-low.Y;local length=high.X-low.X
  if width<40 or length<65 then return end
  local tr=body:K2_GetComponentToWorld()
  local function trace(x,y)
   local p,n={},{}
   local from=mathlib:TransformLocation(tr,{X=x,Y=y,Z=high.Z+70})
   local to=mathlib:TransformLocation(tr,{X=x,Y=y,Z=low.Z})
   if not body:K2_LineTraceComponent(from,to,true,false,false,p,n,{}, {})then return end
   n=mathlib:InverseTransformDirection(tr,n)
   if n.Z<.74 then return end
   return mathlib:InverseTransformLocation(tr,p),n
  end
  local y=(low.Y+high.Y)*.5;local ideal=low.X+length*.53
  local scale=math.min(1,width*.77/136);local feet=48*scale
  local best,value
  for _,fraction in ipairs({.53,.46,.6,.39,.67,.32,.74,.25,.8})do
   local x=low.X+length*fraction
   local left,nl=trace(x,y-feet);local right,nr=trace(x,y+feet)
   if left and right and math.abs(left.Z-right.Z)<12 then
    local mid=trace(x,y);local height=math.max(left.Z,right.Z,mid and mid.Z or -math.huge)
    local score=height-math.abs(x-ideal)*.09-(2-nl.Z-nr.Z)*22
    if not value or score>value then
     local normal={X=(nl.X+nr.X)*.5,Y=(nl.Y+nr.Y)*.5,Z=(nl.Z+nr.Z)*.5}
     local rot=mathlib:MakeRotFromZX(normal,{X=0,Y=1,Z=0})
     best={at={X=x,Y=y,Z=height+.7},rot=rot,scale=scale};value=score
    end
   end
  end
  return best
 end
 local function attach(r)
  local a,fit=r.siren,r.fit;local body=r.car.VehicleMesh
  local giro=a.Giro;giro:SetSimulatePhysics(false);giro:SetCollisionEnabled(0);giro:SetGenerateOverlapEvents(false)
  giro:K2_AttachToComponent(a.RootComponent,FName('None'),0,0,0,false);giro:K2_SetRelativeTransform(identity,false,{},true)
  a:K2_AttachToComponent(body,FName('None'),0,0,0,false);a:K2_SetActorRelativeLocation(fit.at,false,{},true);a:K2_SetActorRelativeRotation(fit.rot,false,{},true)
  a:SetActorRelativeScale3D({X=fit.scale,Y=fit.scale,Z=fit.scale})
 end
 local function setSwitch(r,on)
  local a=r.siren
  a.IsLightOn=on;a:OnRep_IsLightOn();a.IsActiveSiren=on;a:OnRep_IsActiveSiren()
  a:SetActorTickEnabled(on);r.on=on
 end
 local function mount(r,on)
  local car=r.car;local fit=roof(car);if not fit then return end
  local body=car.VehicleMesh;local at=mathlib:TransformLocation(body:K2_GetComponentToWorld(),fit.at)
  local tr={Translation=at,Rotation={X=0,Y=0,Z=0,W=1},Scale3D={X=1,Y=1,Z=1}}
  local cls=LoadAsset('/Game/BP/Items/Movable/Attachable/BP_LargeGiro.BP_LargeGiro_C')
  local a=M.game:BeginDeferredActorSpawnFromClass(car,cls,tr,1,nil,0)
  if not valid(a)then return end
  r.siren=a;r.fit=fit;a:SetReplicates(false);a:SetActorHiddenInGame(true)
  M.game:FinishSpawningActor(a,tr,0);a:SetReplicates(false);a:SetActorEnableCollision(false)
  if valid(a.ItemSaver)then a.ItemSaver.SaveOnDistance=false;a.ItemSaver:SetComponentTickEnabled(false)end
  a.CanBeAttachedToTheCar=false
  if valid(a.AttachableComponent)then a.AttachableComponent:Deactivate();a.AttachableComponent:SetComponentTickEnabled(false)end
  attach(r);setSwitch(r,on);a:SetActorHiddenInGame(false)
 end
 function P.remove(k)
  local r=P.cars[k];if not r then return end
  for _,v in pairs(r.materials)do restore(v)end
  if valid(r.siren)then r.siren.IsActiveSiren=false;r.siren:OnRep_IsActiveSiren();r.siren:K2_DestroyActor()end
  P.cars[k]=nil
 end
 function P.nearest(pc,cars)
  if not valid(pc) or not valid(pc.PlayerControlled)then return end
  local pawn=pc.PlayerControlled;local parent=pawn:GetAttachParentActor();local at=pawn:K2_GetActorLocation()
  local nearest,best=nil,420^2
  for k,car in pairs(cars or {})do if valid(car)then
   if same(pc.Vehicle,car) or same(parent,car)then return k end
   local r=P.cars[k];local q=r and valid(r.siren) and r.siren:K2_GetActorLocation() or car:K2_GetActorLocation()
   local d=(q.X-at.X)^2+(q.Y-at.Y)^2+(q.Z-at.Z)^2
   if d<best and pc:LineOfSightTo(car,{X=0,Y=0,Z=0},false)then nearest=k;best=d end
  end end
  return nearest
 end
 function P.toggle()
  local c=M.appearance;local k=P.nearest(M.H.GetPlayerController(),c.vehicles)
  if k then M.action('siren',not c.switches[k])end
 end
 function P.update(wanted,now,switches)
  for k,r in pairs(P.cars)do if not valid(r.car) or not wanted[k]then P.remove(k)end end
  for k,car in pairs(wanted)do if valid(car)then
   local r=P.cars[k];if not r then r={car=car,materials={},next=0};P.cars[k]=r end
   local on=not switches or switches[k]~=false
   if now>=r.next then
    r.next=now+1.25;refreshPaint(r)
    if not valid(r.siren)then mount(r,on)
    elseif not same(r.siren:GetAttachParentActor(),car) or not same(r.siren.Giro:GetAttachParent(),r.siren.RootComponent)then attach(r)end
   end
   if valid(r.siren) and r.on~=on then setSwitch(r,on)end
  end end
 end
 local function carGuid(a)
  local g=a.GuidGarage
  if g.A~=0 or g.B~=0 or g.C~=0 or g.D~=0 then
   return ('%08x%08x%08x%08x'):format(g.A&0xffffffff,g.B&0xffffffff,g.C&0xffffffff,g.D&0xffffffff)
  end
 end
 local function distance(a,b)return (a.X-b.X)^2+(a.Y-b.Y)^2+(a.Z-b.Z)^2 end
 function P.describe(pc)
  local p=pc.PlayerControlled;if not valid(p)then return end
  local here=p:K2_GetActorLocation();local list={}
  P.ids=P.ids or {}
  for key,a in pairs(M.cars)do if valid(a)then
   local at=a:K2_GetActorLocation();local d=distance(here,at)
   if d<500000^2 then
    if not P.ids[key]then P.sequence=(P.sequence or 0)+1;P.ids[key]=P.sequence end
    local q=M.placement.absolute(a,at)
    local driver
    for _,peer in pairs(M.owners)do
     local c=peer.pc
     if valid(c)and valid(c.PlayerState)and same(c.Vehicle,a)then driver=c.PlayerState.PlayerId;break end
    end
    list[#list+1]={id=P.ids[key],g=carGuid(a),c=a:GetClass():GetFName():ToString(),driver=driver,
     x=math.floor(q.X/100+.5),y=math.floor(q.Y/100+.5),z=math.floor(q.Z/100+.5),on=M.sirenSwitch[key]~=false,d=d}
   end
  end end
  table.sort(list,function(a,b)if a.d==b.d then return a.id<b.id end;return a.d<b.d end)
  while #list>12 do list[#list]=nil end
  for _,row in ipairs(list)do row.d=nil end
  return #list>0 and list or nil
 end
 function P.resolve(rows,cars,players)
  local found,keep={},{};local cached=P.remote or {}
  for _,row in ipairs(rows or {})do
   local car=cached[row.id]
   if not valid(car)then
    local point={X=row.x*100,Y=row.y*100,Z=row.z*100}
    local best,second,candidate=math.huge,math.huge,nil
    for _,a in ipairs(cars)do if valid(a)and a:GetClass():GetFName():ToString()==row.c then
     if row.g and carGuid(a)==row.g then car=a;break end
     if row.driver then
      for _,p in ipairs(players)do
       if valid(p)and valid(p.PlayerState)and p.PlayerState.PlayerId==row.driver and same(p:GetAttachParentActor(),a)then car=a;break end
      end
     end
     if valid(car)then break end
     local d=distance(M.placement.absolute(a,a:K2_GetActorLocation()),point)
     if d<best then second=best;best=d;candidate=a elseif d<second then second=d end
    end end
    if not valid(car)and best<650^2 and math.sqrt(second)-math.sqrt(best)>160 then car=candidate end
   end
   if valid(car)then keep[row.id]=car;found[car:GetAddress()]=row.on end
  end
  P.remote=keep;return found
 end
 function P.reset()for k in pairs(P.cars)do P.remove(k)end;P.ids=nil;P.remote=nil;P.sequence=nil end
 return P
end
