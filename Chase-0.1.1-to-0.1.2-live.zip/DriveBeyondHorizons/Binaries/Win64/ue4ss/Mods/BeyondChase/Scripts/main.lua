local root=assert(debug.getinfo(1,'S').source:sub(2):gsub('\\','/'):match('^(.*)/Scripts/[^/]+$'))
local M={root=root,version='0.1.2',queue={},issued={},suspended={},peers={},owners={},cars={},assigned={},actors={},lastCars={}}
local function module(n)return dofile(root..'/Scripts/'..n..'.lua')end
local function valid(o)return o and o:IsValid()end
local function same(a,b)return valid(a)and valid(b)and a:GetAddress()==b:GetAddress()end
M.valid=valid;M.H=module('local_context')(valid);M.json=module('json')
M.game=StaticFindObject('/Script/Engine.Default__GameplayStatics')
local guid=StaticFindObject('/Script/Engine.Default__KismetGuidLibrary')
local steam=StaticFindObject('/Script/SteamCorePro.Default__SteamUtilities')
local Match=module('match');local prefix='BCVR2 ';local errors={};local nextHello=0
M.log=function(s)print('[Cops vs Runners] '..tostring(s)..'\n')end
M.logOnce=function(e)local s=tostring(e);if not errors[s]then errors[s]=true;M.log(s)end end
function M.note(msg)M.message=tostring(msg):gsub('^.-:%d+: ',''):sub(1,140);if M.tuning then M.tuning.status(M.message)end;if M.ui and M.ui.opened then M.ui.render()end end
local function uid()local g=guid:NewGuid();return ('%08x%08x%08x%08x'):format(g.A&0xffffffff,g.B&0xffffffff,g.C&0xffffffff,g.D&0xffffffff)end
local function now(pc)return M.game:GetTimeSeconds(pc)end
local function alive(p)return valid(p)and valid(p.BP_PlayerStats)and not p.BP_PlayerStats.IsDead and p.BP_PlayerStats.Life>0 end
local function hasCharacter(pc)
 local p=pc.PlayerControlled
 return valid(p)and valid(p.BP_PlayerStats)and (p.IsLoaded or p.IsInitialized)
end
local function pcFor(id)local e=M.owners[id];if e and valid(e.pc) and valid(e.pc.PlayerState)then return e.pc end end
local function read(path)local f=io.open(path,'r');if f then local v=f:read(8192);f:close();return v end end
local function present(name)
 local mods=root..'/../';local marker=io.open(mods..name..'/enabled.txt','rb')
 local enabled=marker~=nil;if marker then marker:close()end
 for line in (read(mods..'mods.txt')or''):gmatch('[^\r\n]+')do local n,v=line:match('^%s*([%w_]+)%s*:%s*(%d)');if n==name then enabled=v=='1'end end
 return enabled and (read(mods..name..'/Scripts/main.lua')~=nil or read(mods..name..'/Scripts/main.lua.chase-previous')~=nil)
end
local suspend,restoreMods=module('companions')(M,present)
local function send(pc,msg)
 if valid(pc)then pc:ClientMessage(prefix..M.json.encode(msg),FName('BeyondChase'),0)end
end
local function bind(pc,ticket)
 local k=pc:GetAddress();local e=M.peers[k];if e and same(e.pc,pc)then return e end
 local id
 if valid(steam) and valid(pc.PlayerState)then
  local ok,s=pcall(function()local n=steam:BreakSteamID(steam:GetSteamIdFromPlayerState(pc.PlayerState));return type(n)=='string' and n or n:ToString()end)
  if ok and s:match('^%d+$')and #s>=15 and not s:match('^0+$')then id='steam'..s end
 end
 if not id then id=type(ticket)=='string'and M.issued[ticket] or nil end
 id=id or uid()
 local prior=M.owners[id];if prior and valid(prior.pc)and not same(prior.pc,pc)then error('This seat is already connected')end
 e={pc=pc,id=id,ticket=prior and prior.ticket or uid()};M.issued[e.ticket]=id;M.peers[k]=e;M.owners[id]=e;return e
end
function M.team(pc)local e=valid(pc)and M.peers[pc:GetAddress()];local p=e and M.round and M.round.roster[e.id];return p and p.team end
local function participating(s)return s and s.phase=='running' and s.me and s.me.ready==true end
function M.live()return participating(M.snapshot)end
function M.localTeam()local p=M.snapshot and M.snapshot.me;return p and p.team end
M.stock={cop={'m4','enfield','ammo','rocket','turbo','pack','pack_medium','pack_large','light','optic'},runner={'ak','hunting','ammo','pack','pack_medium','pack_large','light','optic'}}
M.catalog=Match.catalog
local function stopSystems()
 local function cleanup(fn)local ok,e=pcall(fn);if not ok then M.logOnce(e)end end
 if M.combat and M.combat.active then cleanup(M.combat.stop)end
 if M.tuning then cleanup(M.tuning.stop);M.tuning=nil end
 if M.appearance then cleanup(M.appearance.reset)end
 cleanup(M.equipment.reset);cleanup(M.replicas.reset);M.placement.pending=nil;cleanup(M.route.reset);M.stations={};M.openPC=nil;M.radar=nil;M.sirenSwitch={}
 for _,a in ipairs(M.actors)do if valid(a)and a:HasAuthority()then a:K2_DestroyActor()end end
 M.launchers={};M.actors={};M.assigned={};M.lastCars={};M.cars={};M.serviceAt=nil
end
local function accept(s)
 local before=M.snapshot;M.snapshot=s
 if participating(before) and (not participating(s) or before.serial~=s.serial)then stopSystems();restoreMods()end
 if not s.phase then M.snapshot=nil;if M.ui.opened then M.ui.close()end;return end
 if participating(s) and (not participating(before) or before.serial~=s.serial)then
  if M.ui.opened then M.ui.close()end
  M.message=nil;suspend();M.serviceAt=os.clock()+.5
 end
 if s.me and s.me.skin then M.playerModels.selected=s.me.skin end
 if s.phase=='ended' and (not before or before.phase~='ended') and not M.ui.opened then M.ui.open()elseif M.ui.opened then M.ui.render()end
end
local function snapshot(e)
 local r=M.round;if not r then return {} end
 local p=r.roster[e.id];local counts={cop=0,runner=0};for _,v in pairs(r.roster)do counts[v.team]=counts[v.team]+1 end
 local seats={cop={},runner={}}
 for id,member in pairs(r.roster)do
  local pc=pcFor(id);local nick=member.name or (member.team=='cop' and 'Officer' or 'Runner')
  if pc and valid(pc.PlayerState)then
   local raw=pc.PlayerState:GetPlayerName();local value=(type(raw)=='string' and raw or raw:ToString()):gsub('[%c]','')
   if #value>0 and #value<=48 then nick=value;member.name=value end
  end
  seats[member.team][#seats[member.team]+1]={name=nick,you=id==e.id,online=pc~=nil,ready=member.ready,skin=member.skin}
 end
  for _,list in pairs(seats)do table.sort(list,function(a,b)return a.name<b.name end)end
 local me=p and {team=p.team,skin=p.skin,ready=p.ready,credits=r.funds[p.team],order=p.lastOrder,state=p.state,claimed=r.kits and r.kits[p.team] or false,station=M.equipment.location(p.team),palettes=p.palettes,deaths=p.deaths,remaining=p.due and math.max(0,math.ceil(p.due-now(e.pc))) or 0} or {}
 if p and p.transfer then me.transfer={seq=p.transfer.seq,at=p.transfer.at}end
 return {patrol=r.phase=='running' and M.patrol.describe(e.pc) or nil,build=M.version,serial=r.serial,phase=r.phase,target=r.target,count=counts,seats=seats,score={cop=r.score.cop,runner=r.score.runner},winner=r.winner,total=r.total or 0,votes=r.voteCount or 0,preparing=r.preparing,me=me}
end
local function publish(e,force)
 if not valid(e.pc)then return end
 local s=snapshot(e);local key=M.json.encode(s);if not force and key==e.last then return end;e.last=key
 if same(e.pc,M.H.GetPlayerController())then accept(s)else send(e.pc,{op='state',state=s,ticket=e.ticket})end
end
local function announce()for _,e in pairs(M.peers)do publish(e)end end
local function distance(a,b)return (a.X-b.X)^2+(a.Y-b.Y)^2+(a.Z-b.Z)^2 end
function M.atShop(pc)
 local p=pc.PlayerControlled;local t=M.tuning
 if not valid(p) or not alive(p) or not t then return false end
 for id,r in pairs(t.laptop.items)do
  local data=t.laptop.data[id]
  if data and data.team==M.team(pc) and valid(r.actor) and valid(r.proxy) and not r.closed and r.users and r.users[pc:GetAddress()] and distance(p:K2_GetActorLocation(),r.base:K2_GetComponentLocation())<600^2 then return true end
 end
 return false
end
function M.canTune(pc,id)
 local e=M.peers[pc:GetAddress()];local car=valid(pc.Vehicle)and pc.Vehicle or e and M.lastCars[e.id]
 if not valid(car)then return false end
 local v=M.tuning.vehicle;local motor=v.motor(car);return valid(motor)and v.id(car,motor)==id
end
local paths={m4='/Game/BP/Items/Movable/Weapons/AK/AkWeapon.AkWeapon_C',rocket='/Game/BP/Items/Movable/Bazooka/Bazooka.Bazooka_C',turbo='/Game/BP/CarsV2/System/Actors/Turbo/TurboNormal/TurboGold.TurboGold_C',ammo='/Game/BP/Items/Movable/Bullets/AkBullet.AkBullet_C'}
paths.pack='/Game/BP/Items/Movable/Backpack/BackpackBase.BackpackBase_C'
paths.pack_medium='/Game/BP/Items/Movable/Backpack/BackpackMedium.BackpackMedium_C'
paths.pack_large='/Game/BP/Items/Movable/Backpack/BackpackLarge.BackpackLarge_C'
paths.light='/Game/BP/Items/Movable/ActivableInHand/LampeTorche.LampeTorche_C';paths.optic=paths.light
local function gear(pc,item,at)
 local p=pc.PlayerControlled;local tr={Translation=at,Rotation={X=0,Y=0,Z=0,W=1},Scale3D={X=1,Y=1,Z=1}}
 local cls=LoadAsset((item=='ak' or item=='hunting' or item=='enfield')and paths.m4 or paths[item]);assert(valid(cls),'Equipment unavailable')
 local a=M.game:BeginDeferredActorSpawnFromClass(p,cls,tr,2,nil,0);assert(valid(a),'No clear delivery space')
 local ok,err=pcall(function()
  if item=='ammo'then a.Min=30;a.Max=30;a.NbBullet=30 end
  M.game:FinishSpawningActor(a,tr,0);a:SetReplicates(true)
  if item=='ammo'then a.NbBullet=30 end
  if item=='optic'then assert(M.combat and M.combat.active,'Attachments are loading');M.combat.rail.optic.markItem(a)end
  if item=='m4' or item=='hunting' or item=='enfield'then M.appearance.mark(a,item)end
  if item=='rocket'then M.launchers=M.launchers or {};M.launchers[a:GetAddress()]=a;M.rpg.install()end
  a:FlushNetDormancy();a:ForceNetUpdate()
 end)
 if not ok then a:K2_DestroyActor();error(err)end
 M.actors[#M.actors+1]=a;return a
end
local function deliver(pc,item)
 assert(M.atShop(pc),'Open your team laptop')
 local t=assert(M.tuning,'Equipment is loading');local at=t.delivery.spot(pc)
 
 local bottle=item:match('^bottle(%d)$')
 if bottle then local result;t.induction.nitrous.buy(pc,tonumber(bottle),function(ok,msg)assert(ok,msg);result=msg end);return result end
 gear(pc,item,at);return 'Equipment delivered beside you'
end
local function request(pc,op,value,seq,ticket)
 assert(valid(pc)and pc:HasAuthority(),'Host required')
 local localHost=same(pc,M.H.GetPlayerController())
 if op=='open' and not M.round then
  assert(valid(pc.PlayerState) and hasCharacter(pc),'Wait for your player to load')
  M.round=Match.new(uid());M.nextCheck=0
  M.message=nil
  if not localHost then local owner=M.H.GetPlayerController();if valid(owner)then bind(owner)end end
 end
 if not M.round then return end
 local e=bind(pc,ticket);local r=M.round
 if op=='hello' or op=='open'then publish(e,true);return end
 if op=='join'then r:join(e.id,value)
 elseif op=='arrived'then M.placement.ack(pc,r.roster[e.id],value);return
 elseif op=='ready'then r:setReady(e.id,value)
 elseif op=='leave'then assert(r.phase=='lobby','The pursuit has started');r.roster[e.id]=nil
 elseif op=='skin'then r:skin(e.id,value)
 elseif op=='colors'then
  assert(type(value)=='table' and M.playerModels.policy.validColors(value.id,value.colors),'Invalid outfit palette')
  local member=assert(r.roster[e.id]);local row=type(value.id)=='number' and M.playerModels.catalog[value.id+1]
  assert(r.phase~='ended' and row and row.team==member.team,'Choose your team outfit')
  member.palettes=member.palettes or {};member.palettes[tostring(value.id)]=value.colors:upper()

 elseif op=='limit'then assert(localHost,'Host only');r:limit(value)
 elseif op=='siren'then
  local member=r.roster[e.id];assert(r.phase=='running' and member and member.ready and member.team=='cop' and member.state~='down' and alive(pc.PlayerControlled),'Police only')
  local key=M.patrol.nearest(pc,M.cars);assert(key and type(value)=='boolean','Use the switch in or beside a patrol car')
  M.sirenSwitch=M.sirenSwitch or {};M.sirenSwitch[key]=value;M.appearance.mark(M.cars[key],value and 'patrol_on' or 'patrol_off')
 elseif op=='collect'then M.equipment.collect(pc,e.id)
 elseif op=='radar'then M.equipment.radar(pc,e)
 elseif op=='order'then local result=r:purchase(e.id,seq,value,function(item)return deliver(pc,item)end)
  if localHost then M.note(result)else send(pc,{op='notice',text=result})end
 elseif op=='close'then assert(localHost,'Host only');M.round=nil;if r.preparing then M.route.reset()end;announce();M.snapshot=nil;M.peers={};M.owners={};M.issued={};M.note('Session closed');return
 elseif op~='open'then error('Unknown match request')end
 M.nextCheck=0;announce()
end
local storedTicket=read(root..'/state/reconnect.txt')
function M.action(op,value)
 local pc=M.H.GetPlayerController();if not valid(pc)then return end
 if op=='ready' and value and M.snapshot and M.snapshot.build and M.snapshot.build~=M.version then M.note('The host and every guest need Beyond Chase '..M.version);return end
 if op=='ready' and value and not M.compatible()then M.note('Restart the game once to finish linking the installed Beyond mods.');return end
 local seq=(M.snapshot and M.snapshot.me and M.snapshot.me.order or 0)+1
 if pc:HasAuthority()then local ok,e=pcall(request,pc,op,value,seq);if not ok then M.note(e)end
 else pc:ServerExecRPC(prefix..M.json.encode({op=op,value=value,seq=seq,build=op=='ready' and M.version or nil,ticket=storedTicket,serial=M.snapshot and M.snapshot.serial}))end
end
function M.order(id)M.action('order',id)end
local function rpc()
 RegisterHook('/Script/Engine.PlayerController:ServerExecRPC',function(ctx,msg)
  local text=msg:get():ToString();if #text>300 or text:sub(1,#prefix)~=prefix then return end
  local pc=ctx:get();if not valid(pc) or not pc:HasAuthority()or #M.queue>=48 then return end
  local e=M.peers[pc:GetAddress()];local tick=now(pc)
  if e and e.after and tick<e.after then return end;if e then e.after=tick+.05 end
  M.queue[#M.queue+1]=function()
   if not valid(pc)then return end
   local ok,why=pcall(function()local p=M.json.decode(text:sub(#prefix+1));if p.op~='open' and p.op~='hello' and (not M.round or p.serial~=M.round.serial) then return end
    if p.op=='ready' and p.value and p.build and p.build~=M.version then error('Install Beyond Chase '..M.version..' before readying up')end
    request(pc,p.op,p.value,p.seq,p.ticket)end)
   if not ok then send(pc,{op='notice',text=tostring(why):gsub('^.-:%d+: ',''):sub(1,140)})end
  end
 end)
 RegisterHook('/Script/Engine.PlayerController:ClientMessage',function(ctx,msg,kind)
  if kind:get():ToString()~='BeyondChase'then return end
  local pc=ctx:get();local text=msg:get():ToString()
  if not valid(pc)or pc:HasAuthority()or not pc:IsLocalPlayerController()or #text>8192 or text:sub(1,#prefix)~=prefix then return end
  M.queue[#M.queue+1]=function()
   local p=M.json.decode(text:sub(#prefix+1))
   if p.op=='state'then
    if type(p.ticket)=='string' and p.ticket:match('^%x+$')and #p.ticket==32 and p.ticket~=storedTicket then
     storedTicket=p.ticket;local f=io.open(root..'/state/reconnect.txt','w');if f then f:write(storedTicket);f:close()end
    end
    accept(p.state)
   elseif p.op=='feedback'then M.feedback.receive(p)
   elseif p.op=='radar' and M.localTeam()=='cop' then M.radar=p.points
   elseif p.op=='notice'then M.note(p.text)end
  end
 end)
end
local function ownerOf(a)
 if valid(a)then for id,e in pairs(M.owners)do if valid(e.pc)and (same(e.pc,a)or same(e.pc.PlayerControlled,a))then return id end end end
end
local function cue(id,kind)
 local e=M.owners[id];if not e or not valid(e.pc)then return end
 e.cue=(e.cue or 0)+1
 local msg={op='feedback',serial=M.round.serial,n=e.cue,kind=kind}
 if same(e.pc,M.H.GetPlayerController())then local ok,why=pcall(M.feedback.receive,msg);if not ok then M.logOnce(why)end else send(e.pc,msg)end
end
-- Damage on the victim confirms health loss. The weapon's completed native
-- hit supplies the bone. The Apocalypse bonus reuses the same shot.
function M.reportShot(weapon,target,instigator,bone)
 local r=M.round;local id=ownerOf(target);local victim=r and id and r.roster[id]
 local hit=victim and victim.confirmedHit
 if not hit or not valid(weapon)or not weapon:HasAuthority()then return end
 local attacker=ownerOf(instigator) or ownerOf(weapon:GetInstigatorController()) or ownerOf(weapon.IsEquipedOn)
 if attacker~=hit.by or now(target)-hit.at>.18 then return end
 victim.confirmedHit=nil
 local b=bone and bone:ToString():lower() or ''
 local head=b=='head' or b=='b_head' or b=='skull' or b:match('^head[_%.]')~=nil
 cue(attacker,head and 'head' or 'hit')
end
local function killed(p,source)
 if not M.round or M.round.phase~='running' or not valid(p)or not p:HasAuthority() or alive(p) then return end
 local r=M.round;local id,by=ownerOf(p),ownerOf(source)
 if id and r:death(id,by,now(p))then
  M.dirty=true
  if by and r.roster[by] and r.roster[by].ready and r.roster[by].team~=r.roster[id].team then cue(by,'cash')end
 end
end
local function damageHooks()
 if M.damageInstalled then return end
 local path='/Game/BP/Player/PlayerBase.PlayerBase_C:DealDamage Interface'
 if not valid(StaticFindObject(path))then return end
 RegisterHook(path,function(ctx,amount,instigator,physical,causer)
  if not M.round or M.round.phase~='running'then return end
  local p=ctx:get();local who=instigator:get()
  if not ownerOf(who)then local a=causer:get();who=valid(a)and a:GetInstigatorController()end
  local r=M.round;local by,id=ownerOf(who),ownerOf(p);local victim=id and r.roster[id]
  if victim and victim.state=='alive' and valid(p.BP_PlayerStats)then
   local life=p.BP_PlayerStats.Life
   if by and r.roster[by] and r.roster[by].ready and r.roster[by].team~=victim.team and amount:get()>0 and (not alive(p) or victim.health and life<victim.health)then
    victim.confirmedHit={by=by,at=now(p)}
   end
   victim.health=life
  end
  killed(p,who)
 end)
 M.damageInstalled=true
end
local function connected(id)
 local member=M.round and M.round.roster[id];local pc=pcFor(id)
 return member and member.ready and pc and hasCharacter(pc)
end
local function lobbyTick(pc,p,clock)
 local r=M.round;local gs=M.game:GetGameState(pc)
 if not valid(gs)then return end
 -- PlayerArray includes players who have never opened F6 or installed this mod.
 local byState,online,presentIds={},{},{}
 for id in pairs(M.owners)do local owner=pcFor(id);if owner then byState[owner.PlayerState:GetAddress()]=id end end
 local total=0
 gs.PlayerArray:ForEach(function(_,value)
  local state=value:get()
  if valid(state) and not state.bIsABot and not state.bIsInactive then
   total=total+1
   local id=byState[state:GetAddress()]
   if id then presentIds[id]=true;local owner=pcFor(id);if hasCharacter(owner)then online[id]=true end end
  end
 end)
 for id in pairs(r.roster)do if not presentIds[id]then r.roster[id]=nil end end
 for address,peer in pairs(M.peers)do if not presentIds[peer.id]then
  M.peers[address]=nil
  if M.owners[peer.id]==peer then M.owners[peer.id]=nil end
 end end
 local count,unanimous=r:votes(online,total);r.total=total;r.voteCount=count
 if unanimous then
  r.preparing=true;M.route.survey(p,clock,r)
  if r:begin(M.route.starts,online,total)then r.preparing=nil end
 elseif r.preparing then
  M.route.reset();r.preparing=nil
 end
 announce()
end
local function hostTick(pc,p,clock)
 local r=M.round;if not r or r.phase=='ended'then return end
 M.route.survey(p,clock,r);damageHooks()
 if r.phase=='running' and M.tuning then M.equipment.stations(p)end
 local occupied,runners={},{}
 for id,member in pairs(r.roster)do
  local owner=pcFor(id)
  if owner and connected(id)then
   local pawn=owner.PlayerControlled;M.appearance.mark(pawn,'p'..member.skin..'_'..(member.palettes and member.palettes[tostring(member.skin)] or M.playerModels.policy.stock(member.skin)))
   local car=owner.Vehicle
   if not valid(car)then
    car=pawn:GetAttachParentActor();if valid(car) and not car:IsA(StaticFindObject('/Script/VehicleSystemPlugin.VehicleSystemBase'))then car=nil end
   end
   if valid(car) and alive(pawn) and member.state~='down'then
    M.lastCars[id]=car;if member.team=='cop'then occupied[car:GetAddress()]=car else runners[car:GetAddress()]=true end
   end
   if r.phase=='running'and member.state=='alive'then
    if not alive(pawn)then killed(pawn,nil)
    else
     member.health=pawn.BP_PlayerStats.Life
     if member.team=='runner' and M.tuning then
      if not r.runnerCar and valid(owner.BP_DebugMenuComponent)then owner.BP_DebugMenuComponent:SpawnCar(1,false,true,false,{R=.38,G=.12,B=.055,A=1},false);r.runnerCar=true end
     end
     M.route.checkpoint(id,member,valid(car)and car or pawn,r.sites[member.team],clock)
    end
   end
  end
 end
 M.sirenSwitch=M.sirenSwitch or {}
 for k,car in pairs(M.cars)do
  if not valid(car) or (runners[k] and not occupied[k])then
   if valid(car)then M.appearance.mark(car,nil)end;M.cars[k]=nil;M.sirenSwitch[k]=nil
  end
 end
 for k,car in pairs(occupied)do
  M.cars[k]=car;if M.sirenSwitch[k]==nil then M.sirenSwitch[k]=true end
  M.appearance.mark(car,M.sirenSwitch[k] and 'patrol_on' or 'patrol_off')
 end
 if M.tuning then for _,plan in ipairs(r:plans(clock,connected))do M.placement.place(plan)end end
 if r.phase=='running' and valid(M.route.watch)then
  local waiting=false;for id,member in pairs(r.roster)do if connected(id)and member.state~='alive'then waiting=true end end
  if not waiting then M.route.release()end
 end
 announce()
end
M.stations={};M.equipment=module('equipment')(M,gear,pcFor,send);M.rpg=module('rpg')(M,root,M.H,valid,function(fn)M.queue[#M.queue+1]=fn end,M.log)
M.replicas=module('replicas')(M);M.placement=module('placement')(M);M.route=module('route')(M);M.patrol=module('patrol')(M);M.appearance=module('appearance')(M);M.ui=module('utility')(M);M.feedback=module('feedback')(M)
rpc()
LoopInGameThreadWithDelay(50,function()
 local ok,e=pcall(function()
  local queue=M.queue;M.queue={};for _,fn in ipairs(queue)do local worked,err=pcall(fn);if not worked then M.logOnce(err)end end
  if M.travelling then return end
  if M.feedback.pc then M.feedback.frame()end
  if M.ui.opened then M.ui.hoverTick()end
  if not M.round and not M.snapshot then
   if os.clock()<(M.idleAt or 0)then return end
   M.idleAt=os.clock()+1.5
  end
  local pc=M.H.GetPlayerController();if not valid(pc)then return end
  local p=pc.PlayerControlled;if not hasCharacter(pc)then return end
  local clock=now(pc)
  if M.live()then
   M.replicas.scan(clock)
   if not pc:HasAuthority()then M.placement.client(pc,p,clock);M.equipment.client(pc,p,clock)end
  end
  if not pc:HasAuthority()and clock>=nextHello then
   if not M.snapshot and M.ui.opened then M.action('open')
   elseif M.snapshot or nextHello==0 then M.action('hello')end
   nextHello=clock+(M.snapshot and 8 or 3)
  end
  if M.round and M.round.phase=='lobby' then
   if clock>=(M.nextCheck or 0)then M.nextCheck=clock+.4;lobbyTick(pc,p,clock)end
   return
  end
  if not M.live()then if M.round and M.dirty then M.dirty=nil;announce()end;return end
  if not M.tuning and M.serviceAt and os.clock()>=M.serviceAt then
   M.serviceAt=os.clock()+2;M.tuning=module('services')(M)
   M.combat=M.combat or module('combat')(M);M.combat.start();M.feedback.start(pc,M.snapshot.serial)
  end
  if M.tuning then local worked,err=pcall(M.tuning.tick);if not worked then M.logOnce(err)end end
  if M.combat and M.combat.active then local worked,err=pcall(M.combat.tick,pc,p,clock);if not worked then M.logOnce(err)end end
  if pc:HasAuthority()and (M.dirty or clock>=(M.nextCheck or 0))then M.dirty=nil;M.nextCheck=clock+.25;hostTick(pc,p,clock);if M.round and M.round.phase=='ended'then announce()end end
  if M.live()then M.appearance.tick(clock)end
 end);if not ok then M.logOnce(e)end
end)
RegisterLoadMapPreHook(function()
 M.travelling=true;M.ui.close()
 if M.live()then stopSystems()elseif M.round and M.round.preparing then M.route.reset()end
 M.route.previous=nil
 M.feedback.reset()
 M.round=nil;M.snapshot=nil;M.queue={};M.peers={};M.owners={};M.issued={};M.dirty=nil;nextHello=0
end)
RegisterLoadMapPostHook(function()M.travelling=false;restoreMods()end)
M.log(M.version..' ready. Press F6 in your run to choose a team and ready up.')
return M

